# Skript "prob.R"
# http://www.stat.wisc.edu/~larget/R/prob.R
########################################################################

source("prob.R")

#######################
# Binomialverteilung
########################


# Dichte der Binomialverteilung
dbinom(0:5, 5, 0.1)
# Für einen  Fußballspieler, der 10 mal aufs Tor schießt
# und mit 25% Wahrscheinlichkeit trifft, wie warscheinlich sind
# 5 Treffer? 
dbinom(5, 10, 0.25)
# ... mehr als  3 Treffer
1- pbinom(3, 10, 0.25)
gbinom(10, 0.25, a = 4, b = 10, scale = T)
#dbinom(1, 4, 1/6)
# zwischen 45 und 55 mal Kopf beim Münzwurf:
gbinom(100, 0.5, a = 45, b = 55, scale = T)
# 75% Quantil (3.Quartil)
qbinom(0.75, 200, 0.3)
gbinom(200, 0.3, scale = T, quantile = 0.75)
#Stichprobe
rbinom(20, 10, 0.5)



###############################
#Normalverteilung
###############################
#Bsp: Planzenhöhe ~ N(145, 22)

#Anteil der Planzen, die größer als 100cm sind

1 - pnorm(100, 145, 22)
gnorm(145, 22, a = 100)



#zwischen  120cm und 150cm
pnorm(150, 145, 22) - pnorm(120, 145, 22)
gnorm(145, 22, a = 120, b = 150)

#150 oder weniger
pnorm(150, 145, 22)
gnorm(145, 22, b = 150)

#1. Quartil
qnorm(0.25, 145, 22)
gnorm(145, 22, quantile = 0.25)

#IQR
qnorm(0.75, 145, 22) - qnorm(0.25, 145, 22)
#graphisch
  iqr = qnorm(c(0.25, 0.75), 145, 22)
 gnorm(145, 22, a = round(iqr[1], 1), b = round(iqr[2], 1))





