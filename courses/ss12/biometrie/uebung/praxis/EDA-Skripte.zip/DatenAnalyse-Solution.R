### Infos unter 

### http://uni-leipzig.de/~zuber/teaching/ws11/r-kurs/index.html
## Kurse 1-3


### Aufgabe 1
#Hustensaftdaten

Hustensaft <- c(38.7, 39.6, 37.9, 40.6, 40.5, 37.7, 41.2, 37.5, 39.1)

#plotte emp. Verteilungsfunktion

plot(ecdf(Hustensaft))

var(Hustensaft)
IQR(Hustensaft)

mean(Hustensaft)
median(Hustensaft)

boxplot(Hustensaft)


################################################################################
### Aufgabe 2: Häuserpreise

##install.packages("UsingR")
library("UsingR")



data(homedata)
attach(homedata)

### Refcard: "slicing and extracting data"

### zwei Spalten in der graphischen Ausgabe
par(mfrow =c(1,2)) 

## Jahr 1970
hist(y1970, freq = FALSE, breaks = 100, lwd = 2)
### Dichteschätzung
lines(density(y1970), col = "darkgreen")
## Jahr 2000
hist(y2000, freq = FALSE, breaks = 100,  lwd = 2)
lines(density(y2000), col = "darkgreen")

boxplot( y1970/mean(y1970), y2000/mean(y2000) )


