// MLTree.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)



package vanilla.cui;

import pal.alignment.*;
import pal.datatype.*;
import pal.io.*;
import pal.substmodel.*;
import pal.misc.*;
import pal.eval.*;
import pal.tree.*;
import pal.statistics.*;

import java.io.*;
import java.util.*;


/**
 * omputes likelihood of a data set given a tree and a model of substitution,
 * optimizing of branch lengths and model parameters if desired
 *
 * @version $Id:$
 *
 * @author Korbinian Strimmer
 */
public class MLTree
{
	/**
	 * Usage: mltree [indata intree] 
	 *
	 * @param args command line options (indata intree)
	 */
	public static void main(String[] args)
	{
		System.out.println();
		System.out.println();
		System.out.println("Welcome to MLTREE (" + ReleaseInfo.VERSION + ")!");
		System.out.println();
		System.out.println();

		
		String infileName;
		if (args.length < 1)
		{
			infileName = "indata";
		}
		else
		{
			infileName = args[0];
		}

		String intreeName;
		if (args.length < 2)
		{
			intreeName = "intree";
		}
		else
		{
			intreeName = args[1];
		}
		
		
		// Read data set
		System.out.println();
		System.out.println();		
		System.out.println("Reading input alignment (" + infileName + ")");
		
		PushbackReader in;
		in = FileIO.openIn(infileName);
		Alignment raw = null;
		try
		{
			raw = new ReadAlignment(in);
		}
		catch (AlignmentParseException e)
		{
			System.out.println("Error: Alignment parsing problem");
			System.exit(1);
		}
		catch (IOException e)
		{
			System.out.println("Error: File not found (IO error)");
			System.exit(1);
		}	
		FileIO.close(in);
		
		System.out.println();
		System.out.println("Contains " + raw.getSequenceCount() + " sequences of length " + raw.getSiteCount());
		System.out.println("Likely content: " + raw.getDataType().getDescription() + " data");
		System.out.println();

		
		// Read tree file
		System.out.println();
		System.out.println();
		System.out.println("Reading input tree file (" + intreeName + ")");
		
		
		int numTrees = 0;
		Vector treeVector = new Vector();
		
		in = FileIO.openIn(intreeName);
		SimpleTree tree;
		do
		{
			tree = null;
			try
			{		
				tree = new ReadTree(in); 
			}
			catch (Exception e)
			{
				tree = null;
			}
			
			if (tree != null)
			{
				 // add tree to treeVector
				 numTrees++;
				 treeVector.addElement(tree);
			}
		}	
		while (tree != null);
		FileIO.close(in);
		
		if (numTrees == 0)
		{
			System.out.println("ERROR: Tree file does not contain a valid tree");
			System.exit(1);
		}
		
		System.out.println("Tree file contains " + numTrees + " trees");


		// Set options
		Options options = new Options();
		options.setMLTREE(numTrees);
		options.dtyp = raw.getDataType().getTypeID();
		if (options.dtyp == 1)
		{
			options.smodel = AminoAcidModel.getSuitableModelID(raw.getFrequency());
		}
		options.setOptions();
		
		
		// Start computation
		TimeStamp timeStamp = new TimeStamp();		
		
		raw.setDataType(DataTypeUtils.getInstance(options.dtyp));		
		SitePattern sitePattern = new SitePattern(raw);
		
		System.out.println();
		System.out.println("Computing likelihood");
		
		// create model
		double[] modelFreq;
		if (options.userFreqs)
		{
			modelFreq = options.freq;
		}
		else
		{
			//raw.estimateFrequencies();
			//modelFreq = raw.frequency;
			
			raw.setFrequency(AlignmentUtils.estimateFrequencies(raw));
			modelFreq = raw.getFrequency();
		}
		RateMatrix rmat = RateMatrixUtils.getInstance(options.dtyp, options.smodel,
			options.params, modelFreq);
		RateDistribution rdist = null;
		if (options.rmodel == 0) rdist = new UniformRate();
		if (options.rmodel == 1) rdist = new GammaRates(options.alphaCats, options.alpha);	
		if (options.rmodel == 2) rdist = new InvariableSites(options.fracInv);	
		SubstitutionModel model = new SubstitutionModel(rmat, rdist);	

		// estimate model parameters
		if (options.optModel && model.getNumParameters() > 0)
		{
			System.out.println("Optimising model parameters");
			ModelParameters mp = new ModelParameters(sitePattern, model);
			mp.estimate();
			mp = null;
		}

		// estimate branch lengths
		LikelihoodValue lv = new LikelihoodValue(sitePattern);
		lv.setModel(model);
		
		double[] logL = new double[numTrees];
		double[][] siteLogL = new double[numTrees][sitePattern.numPatterns];
		double[] rate = new double[numTrees];
		double[] rateSE = new double[numTrees];

		for (int i = 0; i < numTrees; i++)
		{
			if (numTrees == 1)
				System.out.println("Evaluating input tree");
			else
				System.out.println("Evaluating tree " + (i+1));
			
			tree = (SimpleTree) treeVector.elementAt(i);
			
			if (options.optTree)
			{
				try
				{
					if (options.branchConstraint == 0)
					{
						lv.setTree(new UnconstrainedTree(tree));
					}
					else if (options.branchConstraint == 1)
					{
						lv.setTree(new ClockTree(tree));
					}
					else if (options.branchConstraint == 2)
					{
						lv.setTree(new DatedTipsClockTree(tree));
					}
				}
				catch (IllegalArgumentException e)
				{
					System.out.println(e);
					System.exit(1);
				}
			}
			else
			{
				lv.setTree(tree);
			}	
		
			//optimise branch lengths
			if (options.optTree)
			{
				lv.optimiseParameters();
			}
			else
			{
				lv.compute();
			}
			
			logL[i] = lv.logL;
			for (int j = 0; j < sitePattern.numPatterns; j++)
			{
				siteLogL[i][j] = lv.siteLogL[j];
			}
			
			if (options.optTree && options.branchConstraint == 2)
			{
				DatedTipsClockTree t = (DatedTipsClockTree) lv.getTree();
				int numParams = t.getNumParameters();
				rate[i] = t.getParameter(numParams-1);
				rateSE[i] = t.getParameterSE(numParams-1);
			}
		}
		
		SimpleTree inputTree = null;
		if (numTrees == 1)
		{
			// clone input tree
			inputTree = new SimpleTree(tree);
		}

		ModelSupport srt = null;
		ShimodairaHasegawaTest sht = null;
		KishinoHasegawaTest kht = null;
		SimpleTree[] btrees = null;
		
		if (numTrees > 1)
		{
			// tree comparison
			if (options.treeTest == 1 || options.treeTest == 4)
			{
				System.out.println("Performing SR tree comparison test");
				srt = new ModelSupport();
				srt.compare(siteLogL, sitePattern.alias, 1000);
			}
			if (options.treeTest == 2 || options.treeTest == 4)
			{
				System.out.println("Performing SH tree comparison test");
				sht = new ShimodairaHasegawaTest();
				sht.compare(siteLogL, sitePattern.alias, 1000);
			}
			if (options.treeTest == 3 || options.treeTest == 4)
			{
				System.out.println("Performing KH tree comparison test");
				kht = new KishinoHasegawaTest();
				kht.compare(siteLogL, sitePattern.alias);
			}
		}
		else if (options.numBootstraps > 0 && options.optTree)
		{			
			BootstrappedAlignment bal = new BootstrappedAlignment(raw);
			SitePattern bsp = null;
			btrees = new SimpleTree[options.numBootstraps];

			System.out.println("Bootstrapping and reestimating branch lengths");
			for (int i = 0; i < options.numBootstraps; i++)
			{
				System.out.println("Repeat #" + (i+1));
				bal.bootstrap();
				bsp = new SitePattern(bal);
				
				lv.renewSitePattern(bsp);
				lv.optimiseParameters();
				
				btrees[i] = new SimpleTree(tree);
			}
		}

		timeStamp.stop();
		
		FormattedOutput fo = FormattedOutput.getInstance();

		try
		{
			if (options.siteLik)
			{
				System.out.println("Writing out site log-likelihood (sitel-lks)");
			
				PrintWriter out = OutputTarget.openFile("sitel-lks");
			
				out.println(numTrees + " " + raw.getSiteCount());
				
				for (int i = 0; i < numTrees; i++)
				{
					for (int j = 0; j < raw.getSiteCount(); j++)
					{
						fo.displayDecimal(out, siteLogL[i][sitePattern.alias[j]], 8);
						out.print(" ");
					}
					out.println();
				}
					
				out.close();
			}
		}
		catch (IOException e)
		{
			System.out.println("Error: file site-lkls could not be created (IO error)");
			System.exit(1);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
		
		
		try
		{

			System.out.println("Writing results to disk (outfile, outtree)");
		
			PrintWriter out = OutputTarget.openFile("outfile");
			PrintWriter out2 = OutputTarget.openFile("outtree");
			
			out.println("MLTREE (" + ReleaseInfo.VERSION + ")");
			out.println();
			timeStamp.report(out);
			out.println();
			out.println();
			out.println("DATA SET");
			out.println();
			AlignmentUtils.report(raw,out);
			out.println();
			out.println();
			
			
			out.println("SUBSTITUTION MODEL");
			out.println();
			model.report(out);
			out.println();
			out.println();
			
			
			for (int i = 0; i < numTrees; i++)
			{
				if (numTrees == 1)
				{
					out.println("TREE TOPOLOGY AND BRANCH LENGTHS (INPUT TREE)");
					tree = (SimpleTree) inputTree;
				}
				else
				{
					out.println("TREE TOPOLOGY AND BRANCH LENGTHS (TREE " + (i+1) + ")");
					tree = (SimpleTree) treeVector.elementAt(i);
				}
				
				out.println();
				TreeUtils.printNH(tree, out);
				out.println();
				
				TreeUtils.printNH(tree, out2);
				out2.println();

				tree.report(out);
				out.println();
				out.print("Log L: ");
				fo.displayDecimal(out, logL[i], 4);
				out.println();

				if (options.optTree && options.branchConstraint == 2)
				{
					out.println();
					out.print("Rate: ");
					fo.displayDecimal(out, rate[i], 7);
					if (rateSE[i] != 0.0)
					{
						out.print(" (S.E. ");
						fo.displayDecimal(out, rateSE[i], 7);
						out.print(")");
					}
					out.println();
				}
			
				out.println();
				if (options.optTree)
				{
					if (options.branchConstraint == 0)
						out.println("Branch lengths are optimised under the ML criterion");
					else if (options.branchConstraint == 1)
						out.println("Branch lengths are optimised under the ML criterion (clock constraint)");
					else if (options.branchConstraint == 2)
						out.println("Branch lengths are optimised under the ML criterion (clock with dated tips)");
				}
				else
				{
					out.println("Branch lengths are user-specified");
				}
				out.println();
				out.println();
				
				out.flush();
			}

			if (numTrees > 1)
			{
				// results of tree comparison
				
				if (options.treeTest == 1 || options.treeTest == 4)
				{
					srt.report(out);
					out.println();
					out.println();
				}
				if (options.treeTest == 2 || options.treeTest == 4)
				{
					sht.report(out);
					out.println();
					out.println();
				}
				if (options.treeTest == 3 || options.treeTest == 4)
				{
					kht.report(out);
					out.println();
					out.println();
				}
			}
			else if (options.numBootstraps > 0 && options.optTree)
			{
				out.println("BOOTSTRAP PRECEDURE");
				out.println();
				out.println("Number of bootstraps: " + options.numBootstraps);
				out.println();
				out.println("Bootstrap trees are written to disk (bootstrap-trees)");
				out.println();
			}
		
			//if (rdist.numRates > 1)
			//{
			//	out.println("M.A.P. ASSIGNMENT OF RATE CATEGORIES TO SITES");
			//
			//	out.println("Site       Rate Category");
			//	for (int i = 0; i < sitePattern.numSites; i++)
			//	{
			//		out.println(i + "          " + lv.rateAtSite[sitePattern.alias[i]]);	
			//	}
			//}
			
			out.close();
			out2.close();

		}
		catch (IOException e)
		{
			System.out.println("Error: file could not be created (IO error)");
			System.exit(1);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}

		if (options.numBootstraps > 0)
		{
			System.out.println("Saving to disk (bootstrap-trees)");
	
			try
			{
				PrintWriter out = OutputTarget.openFile("bootstrap-trees");
			
				for (int i = 0; i < options.numBootstraps; i++)
					TreeUtils.printNH(btrees[i], out);

				out.close();
			}
			catch (IOException e)
			{
				System.out.println("Error: bootstrap-trees could not be created (IO error)");
				System.exit(1);
			}
		}
		
		System.out.println();
	}
 }
