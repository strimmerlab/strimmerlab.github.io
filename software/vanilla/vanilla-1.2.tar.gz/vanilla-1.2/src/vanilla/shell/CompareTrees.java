// CompareTrees.java
//
// (c) 2001 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.tree.*;
import pal.io.*;

import java.io.*;


/**
 * compares two trees and returns Robinson Foulds score
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
 public class CompareTrees
{
	/**
	 * Usage: treecomp treefile1 treefile2
	 *
	 * @param args command line options (treefile1 treefile2)
	 */
	public static void main(String[] args)
	{
	
		MacintoshCommandLine.getArguments(args);

		PrintWriter out;
	
		try
		{
			
			Tree tree1 = new ReadTree(args[0]);
			Tree tree2 = new ReadTree(args[1]);
			
			double distance = TreeUtils.getRobinsonFouldsDistance(tree1, tree2);

			System.out.println(distance);
			

			// Write outfile
			//System.out.println("Writing " + args[numInfiles]);		
			//out = OutputTarget.openFile(args[numInfiles]);
			
			//out.close();
			
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: treecomp treefile1 treefile2");
			}
			catch (IOException e)
			{
				System.out.println("Error: File error (io exception)");
			}
			catch (TreeParseException e)
			{
				System.out.println("Error: Tree parsing problem");
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
 }
