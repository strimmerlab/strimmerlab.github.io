// ShowTree.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.tree.*;
import pal.io.*;

import java.util.*;
import java.io.*;


/**
 * reads treefile, generates ASCII picture,
 * and computes distance matrix induced by branch length
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
 public class ShowTree
{
	/**
	 * showtree treefile [outfile]
	 *
	 * @param args command line options (treefile [outfile])
	 */
	public static void main(String[] args)
	{
		MacintoshCommandLine.getArguments(args);
		
		PrintWriter out;

		try
		{
			int numTrees = 0;
			Vector treeVector = new Vector();
		
			PushbackReader in = InputSource.openFile(args[0]);
			SimpleTree tree;
			do
			{
				tree = null;
				try
				{		
					tree = new ReadTree(in); 
				}
				catch (TreeParseException e)
				{
					tree = null;
				}
			
				if (tree != null)
				{
					// add tree to treeVector
					numTrees++;
				 	treeVector.addElement(tree);
				}
			}	
			while (tree != null);
			in.close();
		
			if (numTrees == 0)
			{
				System.out.println("ERROR: Tree file does not contain a valid tree");
				System.exit(1);
			}
		
			if (args.length < 2)
			{
				out = OutputTarget.openStdOut();
			}	
			else
			{
				out = OutputTarget.openFile(args[1]);
			}
			
			TreeDistanceMatrix mat;
			for (int i = 0; i < numTrees; i++)
			{
			
				tree = (SimpleTree) treeVector.elementAt(i);
				mat = new TreeDistanceMatrix(tree);

				out.println("USER TREE #" + (i+1));
				out.println();
				TreeUtils.printNH(tree, out);
				out.println();			
				tree.report(out);
				out.println();	
				out.println();
				out.println("INDUCED DISTANCE MATRIX");
				out.println();
				mat.printPHYLIP(out);
				out.println();
				out.println();
			}
			
			out.close();
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: showtree treefile [outfile]");
			}
			catch (IOException e)
			{
				System.out.println("Error: File not found (IO error)");
			}
			//catch (Exception e)
			//{
			//	System.out.println(e);
			//}
	}
 }
