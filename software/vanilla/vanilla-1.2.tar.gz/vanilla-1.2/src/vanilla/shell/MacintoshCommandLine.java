// MacintoshCommandLine.java
//
// (c) 2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.io.*;

import java.io.*;
import java.util.*;


/**
 * reads command line arguments on Macintosh platform
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
public class MacintoshCommandLine
{
	//
	// Public stuff
	//

	/** get command line arguments (arg is passed through if OS != Mac OS */
	public static String[] getArguments(String[] arg)
	{
		String osName = System.getProperty("os.name");
				
		if (osName.equals("Mac OS"))
		{
			System.out.println("Welcome on the Macintosh!");
			System.out.println();
			System.out.print("Please enter command line parameters: ");
			
			PushbackReader in = InputSource.openStdIn();
			FormattedInput fi = FormattedInput.getInstance();
			String str;
			try
			{
				str = fi.readLine(in, true);
			}
			catch (IOException e)
			{
				str = "";
			}
			
			StringTokenizer st = new StringTokenizer(str);
			
			int numArgs = st.countTokens();
			
			arg = new String[numArgs];
			for (int i = 0; i < numArgs; i++)
			{
				arg[i] = st.nextToken();
			}
			
			System.out.println();
			System.out.println();
			
			return arg;
		}
		else
		{
			return arg;
		}
	}
}
