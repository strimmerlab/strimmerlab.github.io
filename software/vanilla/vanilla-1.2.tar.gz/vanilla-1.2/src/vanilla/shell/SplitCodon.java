// SplitCodon.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.alignment.*;
import pal.io.*;

import java.io.*;


/**
 * separate 1st, 2nd, 3rd codon positions
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
public class SplitCodon
{
	/**
	 * Usage: splitcodon infile outfile
	 *
	 * @param args command line options (infile outfile)
	 */
	public static void main(String[] args)
	{
		MacintoshCommandLine.getArguments(args);
		
		PrintWriter out;
	
		try
		{
			Alignment raw =
			new ReadAlignment(args[0]);
	
			StrippedAlignment[] stripped = new StrippedAlignment[3];

			for (int i = 0; i < 3; i++)
			{
				stripped[i] = new StrippedAlignment(raw);
				
				// Strip all sites except i, i+3, i+6, etc.
				for (int s = 0; s < raw.getSiteCount(); s++)
				{
					if ( ((s-i) % 3) != 0)
					{
						stripped[i].dropSite(s);
					}
				}
				
				String name = null;
				if (i == 0)
				{
					name = args[1] + ".1st";
				}
				if (i == 1)
				{
					name = args[1] + ".2nd";
				}
				if (i == 2)
				{
					name = args[1] + ".3rd";
				}
				
			
				out = OutputTarget.openFile(name);		
				AlignmentUtils.print(stripped[i],out);
				out.close();
				
				if (i == 0) System.out.print("First");
				if (i == 1) System.out.print("Second");
				if (i == 2) System.out.print("Third");
				System.out.println(" codon positions written to file (" + name + ")");
			}
			
			
			
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: splitcodon infile outfile");
			}
			catch (IOException e)
			{
				System.out.println("Error: File not found (IO error)");
			}
			catch (AlignmentParseException e)
			{
				System.out.println("Error: Parsing problem");
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
 }
