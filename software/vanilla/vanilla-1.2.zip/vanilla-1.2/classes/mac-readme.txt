On the Macintosh please move the class files

  pal.zip
  vanilla.zip
  
into the "MRJ Classes" folder.

This folder sits in the "MRJ Libraries" directory
which itself is located in the extensions folder of
the System folder. 

This adds the PAL and Vanilla classes to the MRJ CLASSPATH.

You still need to create JBindary files for each application
(pre-MacOS X).
