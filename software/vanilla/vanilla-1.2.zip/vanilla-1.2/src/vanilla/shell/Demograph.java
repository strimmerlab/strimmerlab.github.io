// Demograph.java
//
// (c) 2000-2001 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.coalescent.*;
import pal.eval.*;
import pal.misc.*;
import pal.math.*;
import pal.tree.*;
import pal.io.*;
import pal.statistics.*;

import java.util.*;
import java.io.*;


/**
 * Estimates demographic parameters (effective population size, growth rate)
 * by maximising the coalescent prior for a single given clocklike tree.
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
 public class Demograph
{
	/**
	 * demograph intree outfile
	 *
	 * @param args command line options intree [epsilon] outfile
	 */
	public static void main(String[] args) throws TreeParseException
	{
		MacintoshCommandLine.getArguments(args);
		
		FormattedOutput fo = FormattedOutput.getInstance();
		
		PrintWriter out;

		boolean bootstrap = false; // no boostrap at present
		
		double epsilon = 0.0;
		if (args.length == 3) epsilon = Double.parseDouble(args[1]);
		
		try
		{
			SimpleTree tree = new ReadTree(args[0]);
			
			if (bootstrap)
				out = OutputTarget.openFile(args[2]);
			else
				out = OutputTarget.openFile(args[1]);
			
			out.println("DEMOGRAPH (" + ReleaseInfo.VERSION + ")");
			
			/*out.println();
			out.println();
			out.println("INPUT TREE");				
			out.println();
			TreeUtils.printNH(tree, out);
			out.println();							
			tree.report(out);
			out.println();
			
			TreeUtils.report(tree, out);	*/
							
			CoalescentIntervals coi = IntervalsExtractor.extractFromClockTree(tree);
			
			out.println();
			out.println();
			out.println("COALESCENT INTERVALS");
			out.println();
			coi.report(out);
			
			if (bootstrap)
			{
				System.out.println("Skipping parametric estimates");
			}
			else
			{
				System.out.println("Computing parametric estimates");
			
				out.println("PARAMETRIC ESTIMATES OF DEMOGRAPHIC HISTORY");
				out.println();	
				DemographicValue dv = new DemographicValue();
				dv.setCoalescentIntervals(coi);
							
				DemographicModel cp = new ConstantPopulation(coi.getUnits());
				dv.setDemographicModel(cp);		
				dv.optimize();
				cp.report(out);
				out.println();
				
				double l1 = dv.logL;
				
				out.println("--");
				out.println();
			
				DemographicModel gr = new ExponentialGrowth(coi.getUnits());				
				dv.setDemographicModel(gr);
				dv.optimize();								
				gr.report(out);
				out.println();
				
				double l2 = dv.logL;

				/*
				out.println();
				out.println("EXPANDING POPULATION MODEL");
				out.println();
				
				DemographicModel expanding = new ExpandingPopulation(coi.getUnits());				
				dv.setDemographicModel(expanding);
				dv.optimize();								
				expanding.report(out);
				out.println();

				double l3 = dv.logL;
				*/

				// likelihood ratio test
				double delta = l2-l1;
				if (delta < 0) delta = 0;
				double pval  = LikelihoodRatioTest.getSignificance(delta, 1);
				out.println("--");
				out.println();
				out.println("Likelihood ratio test (Chi-square-distribution) ");
				out.print("significance level: ");
				fo.displayDecimal(out, pval, 4);
				out.println();
				out.println();
				if (pval <= 0.05)
				{
					out.println("The simpler model (constant population) can be rejected");
					out.println("on a significance level of 5%");
				}
				else
				{
					out.println("The simpler model (constant population) can NOT be rejected");
					out.println("on a significance level of 5%");
				}
				out.println();
				out.println();
			}
				
			System.out.println("Computing non-parametric estimates");
				
			out.println("NON-PARAMETRIC ESTIMATES OF DEMOGRAPHIC HISTORY");
			out.println();
			
			out.println("Coalescent intervals <= " + epsilon + " are pooled when computing the generalized skyline plot.");
			out.println();
			if (!bootstrap)
			{
				SkylinePlot skyplot = new SkylinePlot(tree, epsilon);
				skyplot.report(out);
				out.flush();

				out.println();
				out.println();
				
				ClassicSkylinePlot skyplot2 = new ClassicSkylinePlot(tree);
				skyplot2.report(out);
				out.flush();
			}
			else if (bootstrap)
			{
				int numTrees = 0;
				Tree refTree = tree;
				Vector treeVector = new Vector();
							
				PushbackReader in = InputSource.openFile(args[1]);

				do
				{
					tree = null;
					try
					{		
						tree = new ReadTree(in); 
					}
					catch (TreeParseException e)
					{
						tree = null;
					}
					if (tree != null)
					{
					 	// add skyline plot to treeVector
						numTrees++;
				 		//treeVector.addElement(new SkylinePlot(tree, POOLING));
						treeVector.addElement(tree);
					}
				}	
				while (tree != null);
				in.close();
		
				if (numTrees == 0)
				{
					System.out.println("ERROR: bootstrap tree file does not contain a valid tree");
					System.exit(1);
				}
				else
				{
					System.out.println("Number of bootstrap trees: " + numTrees);
				}
		
				Tree[] bootstraps = new Tree[numTrees];
				for (int i = 0; i < numTrees; i++)
				{
					bootstraps[i] = (Tree) treeVector.elementAt(i);
				}
				
				SkylinePlot skyplot = new SkylinePlot(refTree, bootstraps, epsilon);
				skyplot.report(out);
			}
						
			out.println();	
			
			out.close();
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: demograph treefile [epsilon] outfile");
			}
			catch (IOException e)
			{
				System.out.println("Error: File not found (IO error)");
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
 }
