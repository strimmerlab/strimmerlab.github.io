// Rewrite.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.cui;

import pal.alignment.*;
import pal.io.*;
import pal.misc.*;

import java.io.*;


/**
 * utility program for reformating sequence alignments, bootstrapping
 * and some other stuff
 *
 * @version $Id: June 17 2000$
 */
public class Rewrite
{
	/**
	 * Usage: rewrite [indist]
	 *
	 * @param args command line options (indist)
	 */
	public static void main(String[] args)
	{
		System.out.println();
		System.out.println();
		System.out.println("Welcome to REWRITE (" + ReleaseInfo.VERSION + ")!");
		System.out.println();
		System.out.println();

		String infileName;
		if (args.length < 1)
		{
			infileName = "indata";
		}
		else
		{
			infileName = args[0];
		}

		// Read data set
		System.out.println();
		System.out.println();		
		System.out.println("Reading input alignment (" + infileName + ")");
		
		PushbackReader in;
		in = FileIO.openIn(infileName);
		Alignment raw = null;
		try
		{
			raw = new ReadAlignment(in);
		}
		catch (AlignmentParseException e)
		{
			System.out.println("Error: Alignment parsing problem");
			System.exit(1);
		}
		catch (IOException e)
		{
			System.out.println("Error: File not found (IO error)");
			System.exit(1);
		}	
		FileIO.close(in);
		

		System.out.println();
		System.out.println("Contains " + raw.numSeqs + " sequences of length " + raw.numSites);
		System.out.println("Likely content: " + raw.dataType.getDescription() + " data");
		System.out.println();
		

		// Set options
		Options options = new Options();
		options.setREWRITE();
		options.setOptions();
		System.out.println();
		
		
		System.out.println("Writing results to disk (outdata)");
		System.out.println();
		
		Alignment al = raw;
		if (options.dropGaps || options.dropSites > 0)
		{
			al = new StrippedAlignment(al);
			if(options.dropGaps)
			{
				((StrippedAlignment) al).removeGaps();
			}
			if(options.dropSites == 1)
			{
				((StrippedAlignment) al).removeConstantSites();
			}
			if(options.dropSites == 2)
			{
				((StrippedAlignment) al).removeNoninformativeSites();
			}
			
		}

		JumbledAlignment jal = null;
		if (options.jumble)
		{
			jal = new JumbledAlignment(al);
			al = jal;
		}

		BootstrappedAlignment bal = null;
		if (options.bootstrap)
		{
			bal = new BootstrappedAlignment(al);
			al = bal;
		}

		try
		{
			PrintWriter out = OutputTarget.openFile("outdata");
			
			for (int i = 0; i < options.numDataSets; i++)
			{
				if (options.jumble) jal.jumble();
				if (options.bootstrap) bal.bootstrap();
				
				if (options.format == 0) al.printInterleaved(out);
				if (options.format == 1) al.printPlain(out);
				if (options.format == 2) al.printCLUSTALW(out);
				if (options.format == 3) al.printSequential(out);
				out.println();
				out.println();
				
			}

			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outdata could not be created (IO error)");
			System.exit(1);
		}
		
		

	}
 }
