// FileIO.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)
//
// Last modified April 12 2000


package vanilla.cui;

import pal.io.*; 

import java.io.*;


/**
 * convenient interface for file IO from CUI programs
 */
public class FileIO
{
	//
	// Public stuff
	//
	
	//
	// Friendly stuff
	//

	// Name of last opened file
	static String fileName;

	// Open file for writing
	static PrintWriter openOut(String name)
	{
		int count = 0;
		boolean repeat;
		PrintWriter out = null;
		
		fileName = name;
		
		do
		{
			try
			{
				repeat = false;
				out = OutputTarget.openFile(fileName);
			}
			
			catch (IOException e)
			{
				repeat = true;
				count++;
			
				if (count == 1)
				{
					input = InputSource.openStdIn();
					fi = FormattedInput.getInstance();
				}
			
				System.out.print("File '" + fileName + "' not created, please enter alternative name: ");
				
				try
				{
					fileName = fi.readLine(input, true);
				}
				
				catch (IOException e2)
				{
					System.exit(1);
				}
			}
		}
		while (repeat && count < 10);
		
		if (count == 10)
		{
			System.out.println("To many trials - quitting ...");
			System.exit(1);
		}
		
		return out;
	}

	// Open file for reading
	static PushbackReader openIn(String name)
	{
		int count = 0;
		boolean repeat;
		PushbackReader in = null;
		fileName = name;
		
		do
		{
			try
			{	
				repeat = false;
				in = InputSource.openFile(fileName);
			}
		
			catch (IOException e)
			{
				repeat = true;
				count++;
			
				if (count == 1)
				{
					input = InputSource.openStdIn();
					fi = FormattedInput.getInstance();
				}
			
				System.out.print("File '" + fileName + "' not found, please enter alternative name: ");
				
				try
				{
					fileName = fi.readLine(input, true);
				}
				
				catch (IOException e2)
				{
					System.exit(1);
				}
			}
		}
		while (repeat && count < 10);
		
		if (count == 10)
		{
			System.out.println("To many trials - quitting ...");
			System.exit(1);
		}
		
		return in;	
	}
	
	// Close streams
	static void close(PrintWriter out)
	{
		out.close();
	}

	static void close(PushbackReader in)
	{
		try
		{
			in.close();
		}
		
		catch (IOException e)
		{
			System.out.println("IO error while closing file stream - quitting ...");
			System.exit(1);
		}
	}
	
	//
	// Private stuff
	//
	
	private static PushbackReader input;
	private static FormattedInput fi;
}
