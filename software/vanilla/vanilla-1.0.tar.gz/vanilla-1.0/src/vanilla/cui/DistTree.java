// DistTree.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.cui;

import pal.distance.*;
import pal.tree.*;
import pal.io.*;
import pal.eval.*;
import pal.misc.*;

import java.io.*;
import java.util.*;


/**
 * distance matrix methods (neighbor-joining, upgma,
 * least-squares branch length estimation for user trees)
 *
 * @version $Id: June 27 2000$
 */
public class DistTree
{
	/**
	 * Usage: disttree indist intree
	 *
	 * @param args command line options (indist intree)
	 */
	public static void main(String[] args)
	{

		System.out.println();
		System.out.println();
		System.out.println("Welcome to DISTTREE (" + ReleaseInfo.VERSION + ")!");
		System.out.println();
		System.out.println();

		String indistName;
		if (args.length < 1)
		{
			indistName = "indist";
		}
		else
		{
			indistName = args[0];
		}

		String intreeName;
		if (args.length < 2)
		{
			intreeName = "intree";
		}
		else
		{
			intreeName = args[1];
		}


		// Read data set
		System.out.println();
		System.out.println();		
		System.out.println("Reading input distance (" + indistName + ")");

		PushbackReader in;
		
		in = FileIO.openIn(indistName);

		ReadDistanceMatrix mat = null;
		try
		{
			mat = new ReadDistanceMatrix(in);
		}
		catch (DistanceParseException e)
		{
			System.out.println("Error: Parsing problem (distances)");
			System.exit(1);
		}
		FileIO.close(in);
		

		System.out.println("Contains distances for " + mat.numSeqs + " sequences");
	
		// Set options
		Options options = new Options();
		options.setDISTTREE();
		options.setOptions();
		System.out.println();

		SimpleTree tree = null;
		int numTrees = 0;
		Vector treeVector = null;
		if (options.distMethod == 0)
		{
			// Read tree file
			System.out.println();
			System.out.println();
			System.out.println("Reading input tree file (" + intreeName + ")");
			
			numTrees = 0;
			treeVector = new Vector();
			
			in = FileIO.openIn(intreeName);
			
			do
			{
				tree = null;
				try
				{		
					tree = new ReadTree(in); 
				}
				catch (Exception e)
				{
					tree = null;
				}
				
				if (tree != null)
				{
					 // add tree to treeVector
					 numTrees++;
					 treeVector.addElement(tree);
				}
			}	
			while (tree != null);
			FileIO.close(in);
			
			if (numTrees == 0)
			{
				System.out.println("ERROR: Tree file does not contain a valid tree");
				System.exit(1);
			}
			
			System.out.println("Tree file contains " + numTrees + " trees");
		}

		
		// Start computation
		TimeStamp timeStamp = new TimeStamp();		
	
		double[] sumOfSquares = null;
		if (options.distMethod == 0)
		{
			ChiSquareValue cs = new ChiSquareValue(mat, options.weightedLS);
			sumOfSquares = new double[numTrees];
			for (int i = 0; i < numTrees; i++)
			{
				System.out.println("Evaluating tree " + (i+1));
				tree = (SimpleTree) treeVector.elementAt(i);
				
			if (options.optTree)
			{
				if (options.branchConstraint == 0)
				{
					cs.setTree(new UnconstrainedTree(tree));
				}
				else if (options.branchConstraint == 1)
				{
					cs.setTree(new ClockTree(tree));
				}
				else if (options.branchConstraint == 2)
				{
					cs.setTree(new DatedTipsClockTree(tree));
				}
			}
				else
				{
					cs.setTree(tree);
				}

				//optimise branch lengths
				if (options.optTree)
				{
					sumOfSquares[i] = cs.optimiseParameters();
				}
				else
				{
					sumOfSquares[i] = cs.compute();
				}
			}
		}

		
		if (options.distMethod == 1)
		{
			tree = new NeighborJoiningTree(mat);
		}
		if (options.distMethod == 2)
		{
			tree = new UPGMATree(mat);
		}
		
		timeStamp.stop();
		
		System.out.println("Writing results to disk (outfile, outtree)");
		System.out.println();
		
		PrintWriter out = null;	
		PrintWriter out2 = null;	
		try
		{
			out = OutputTarget.openFile("outfile");
			out2 = OutputTarget.openFile("outtree");

		}
		catch (IOException e)
		{
			System.out.println("Error: IO problem");
			System.exit(1);		
		}
			
		out.println("DISTTREE (" + ReleaseInfo.VERSION + ")");
		out.println();
		timeStamp.report(out);
		out.println();
		out.println();

		if (options.distMethod == 0)
		{
			for (int i = 0; i < numTrees; i++)
			{
				tree = (SimpleTree) treeVector.elementAt(i);
			
				out.println("TREE WITH LEAST SQUARES BRANCH LENGTHS (TREE " + (i+1) + ")");
				out.println();
				if (options.weightedLS)
				{
					out.println("Method: Fitch and Margoliash (1967), weighted LS");
				}
				else
				{
					out.println("Method: Cavalli-Sforza and Edward (1967), unweighted LS");
				}
				out.println();
				tree.printNH(out);
				out.println();
				
				tree.printNH(out2);
				out2.println();
							
				tree.report(out);
				out.println();
			
				if (options.branchConstraint == 1)
				{
					out.println("Branch lengths have been constrained to follow a clock");
					out.println();
				}
				else if (options.branchConstraint == 2)
				{
					out.println("Branch lengths have been constrained to follow a dated tips clock");
					out.println();
				}
						
				out.print("Sum of squares: ");	
				FormattedOutput fo = FormattedOutput.getInstance();
				fo.displayDecimal(out, sumOfSquares[i], 4);
				out.println();
				out.println();
				out.println();
				out.flush();
			}
		}
		if (options.distMethod > 0)
		{
			if (options.distMethod == 1) out.println("NEIGHBOR-JOINING TREE");
			if (options.distMethod == 2) out.println("UPGMA TREE");
			out.println();
			out.println();
			tree.printNH(out);
			out.println();
				
			tree.printNH(out2);
			out2.println();
							
			tree.report(out);
			out.println();
		}	
		out.close();
		out2.close();
	}
 }
