// MLDist.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)

package vanilla.cui;

import pal.alignment.*;
import pal.datatype.*;
import pal.distance.*;
import pal.io.*;
import pal.substmodel.*;
import pal.misc.*;
import pal.eval.*;

import java.io.*;


/**
 * computes observed and maximum likelihood distances from sequences
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
public class MLDist
{
	/**
	 * Usage: mldist 
	 *
	 * @param args command line options ()
	 */
	public static void main(String[] args)
	{
		System.out.println();
		System.out.println();
		System.out.println("Welcome to MLDIST (" + ReleaseInfo.VERSION + ")!");
		System.out.println();
		System.out.println();

		// Read data set
		String indataName;
		if (args.length == 0)
		{
			indataName = "indata";
		}
		else
		{
			indataName = args[0];
		}
		
		System.out.println();
		System.out.println();
		System.out.println("Reading input alignment (" + indataName + ")");
		
		PushbackReader in;
		in = FileIO.openIn(indataName);
		Alignment raw = null;
		try
		{
			raw = new ReadAlignment(in);
		}
		catch (AlignmentParseException e)
		{
			System.out.println("Error: Alignment parsing problem");
			System.exit(1);
		}
		catch (IOException e)
		{
			System.out.println("Error: File not found (IO error)");
			System.exit(1);
		}	
		FileIO.close(in);
		
		System.out.println();
		System.out.println("Contains " + raw.numSeqs + " sequences of length " + raw.numSites);
		System.out.println("Likely content: " + raw.dataType.getDescription() + " data");
		System.out.println();
		

		// Set options
		Options options = new Options();
		options.setMLDIST();
		options.dtyp = raw.dataType.getTypeID();
		if (options.dtyp == 1)
		{
			options.smodel = AminoAcidModel.getSuitableModelID(raw.frequency);
		}
		options.setOptions();
		
		
		// Start computation
		TimeStamp timeStamp = new TimeStamp();

		// Compute distances
		raw.dataType = DataType.getInstance(options.dtyp);
		
		SitePattern sitePattern = new SitePattern(raw);
		
		DistanceMatrix mat = null;
		
		System.out.println();
		System.out.println("Computing distance matrix");
		
		SubstitutionModel model = null;
		if (options.useModel)
		{
			// create model
			double[] modelFreq;
			if (options.userFreqs)
			{
				modelFreq = options.freq;
			}
			else
			{
				raw.estimateFrequencies();
				modelFreq = raw.frequency;
			}
			RateMatrix rmat = RateMatrix.getInstance(options.dtyp, options.smodel,
				options.params, modelFreq);
			RateDistribution rdist = null;
			if (options.rmodel == 0) rdist = new UniformRate();
			if (options.rmodel == 1) rdist = new GammaRates(options.alphaCats, options.alpha);	
			model = new SubstitutionModel(rmat, rdist);	
		
			// estimate model parameters
			if (options.optModel && model.getNumParameters() > 0)
			{
				System.out.println("Optimising model parameters");
				ModelParameters mp = new ModelParameters(sitePattern, model);
				mp.estimate();
				mp = null;
			}

			mat = new AlignmentDistanceMatrix(sitePattern, model);
		}
		else mat = new AlignmentDistanceMatrix(sitePattern);

		timeStamp.stop();

		System.out.println("Saving to disk (outfile, outdist)");
		System.out.println();

		try
		{
			PrintWriter out = OutputTarget.openFile("outfile"); 			
			
			out.println("MLDIST (" + ReleaseInfo.VERSION + ")");
			out.println();
			timeStamp.report(out);
			out.println();
			out.println();
			out.println("DATA SET");
			out.println();
			raw.report(out);
			out.println();
			out.println();
			
			if (options.useModel)
			{
				out.println("SUBSTITUTION MODEL");
				out.println();
				model.report(out);
				out.println();
				out.println();
				out.println("MAXIMUM LIKELIHOOD DISTANCES");
			}
			else
			{
				out.println("OBSERVED DISTANCES");
			}
			out.println();
			mat.printPHYLIP(out);

			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outfile could not be created (IO error)");
			System.exit(1);
		}
		
		try
		{
			PrintWriter out = OutputTarget.openFile("outdist");
			
			mat.printPHYLIP(out);

			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outdist could not be created (IO error)");
			System.exit(1);
		}
	}
 }
