// Demograph.java
//
// (c) 2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.coalescent.*;
import pal.eval.*;
import pal.misc.*;
import pal.math.*;
import pal.tree.*;
import pal.io.*;
import pal.statistics.*;

import java.util.*;
import java.io.*;


/**
 * Estimates demographic parameters (effective population size, growth rate)
 * by maximising the coalescent prior for a single given clocklike tree.
 * Also computes the skyline plot, a non-parametric estimate of population size
 * through time (Pybus et al.  2000. Genetics 155:1429-1437). 
 *
 * @version $Id: 15 July 2000$
 *
 * @author Korbinian Strimmer
 */
 public class Demograph
{
	/**
	 * demograph intree outfile
	 *
	 * @param args command line options intree outfile
	 */
	public static void main(String[] args)
	{
		MacintoshCommandLine.getArguments(args);
		
		PrintWriter out;

		try
		{
				SimpleTree tree = new ReadTree(args[0]);
			
				out = OutputTarget.openFile(args[1]);

				out.println("DEMOGRAPH (" + ReleaseInfo.VERSION + ")");
				out.println();
				out.println();
				out.println("INPUT TREE");
				out.println();
				tree.printNH(out);
				out.println();			
				tree.report(out);
				out.println();	
								
				CoalescentIntervals coi = IntervalsExtractor.extractFromTree(tree);
				
				out.println();
				out.println("COALESCENT INTERVALS");
				out.println();
				coi.report(out);
				out.println();
				

				DemographicValue dv = new DemographicValue();
				dv.setCoalescentIntervals(coi);

				
				out.println("CONSTANT POPULATION MODEL");
				out.println();				
				DemographicModel cp = new ConstantPopulation(coi.getUnits());
				dv.setDemographicModel(cp);		
				dv.optimize();
				cp.report(out);
				out.println();

				double l1 = dv.logL;
				
				out.println();
				out.println("EXPONENTIAL GROWTH MODEL");
				out.println();
				DemographicModel gr = new ExponentialGrowth(coi.getUnits());				
				dv.setDemographicModel(gr);
				dv.optimize();								
				gr.report(out);
				out.println();

				double l2 = dv.logL;

				/*
				out.println();
				out.println("EXPANDING POPULATION MODEL");
				out.println();
				
				DemographicModel expanding = new ExpandingPopulation(coi.getUnits());				
				dv.setDemographicModel(expanding);
				dv.optimize();								
				expanding.report(out);
				out.println();

				double l3 = dv.logL;
				*/

				// likelihood ratio test
				double delta = l2-l1;
				if (delta < 0) delta = 0;
				double pval  = LikelihoodRatioTest.getSignificance(delta, 1);
				out.println();
				out.println("LIKELIHOOD RATIO TEST (CHI2-DISTRIBUTION)");
				out.println();
				out.println("Significance level: " + pval);
				out.println();
				if (pval <= 0.05)
				{
					out.println("The simpler model (constant population) can be rejected");
					out.println("on a significance level of 5%");
				}
				else
				{
					out.println("The simpler model (constant population) can NOT be rejected");
					out.println("on a significance level of 5%");
				}

				out.println();
				out.println();
				out.println("SKYLINE PLOT (to be viewed in EXCEL or similar)");
				out.println();


				SkylinePlot skyplot = new SkylinePlot(coi);
				skyplot.report(out);

			
			out.close();
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: demograph treefile [outfile]");
			}
			catch (IOException e)
			{
				System.out.println("Error: File not found (IO error)");
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
 }
