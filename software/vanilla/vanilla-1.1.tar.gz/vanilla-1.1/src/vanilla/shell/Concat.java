// Concat.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.alignment.*;
import pal.io.*;

import java.io.*;


/**
 * concatenates alignments 
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
 public class Concat
{
	/**
	 * Usage: concat infile1 infile2 .. outfile
	 *
	 * @param args command line options (infile1 infile2 .. outfile)
	 */
	public static void main(String[] args)
	{
	
		MacintoshCommandLine.getArguments(args);

		PrintWriter out;
	
		try
		{
			// Number of input alignments
			int numInfiles = args.length-1;
			if (numInfiles <= 0)
			{
				throw new ArrayIndexOutOfBoundsException();
			}
			Alignment[] infile = new Alignment[numInfiles];

			// Read alignments
			System.out.println();
			for (int i = 0; i < numInfiles; i++)
			{
				System.out.println("Reading " + args[i]);
				infile[i] = new ReadAlignment(args[i]);

			}

			// Create concatenated alignment
			Alignment all = new ConcatenatedAlignment(infile);


			// Write outfile
			System.out.println("Writing " + args[numInfiles]);		
			out = OutputTarget.openFile(args[numInfiles]);
			all.print(out);
			out.close();
			
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: concat infile1 infile2 .. outfile");
			}
			catch (IOException e)
			{
				System.out.println("Error: File error (io exception)");
			}
			catch (AlignmentParseException e)
			{
				System.out.println("Error: Alignment parsing problem");
			}
			catch (IllegalArgumentException e)
			{
				System.out.println("Error: Incompatible alignments");
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
 }
