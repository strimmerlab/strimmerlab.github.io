// Reroot.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.shell;

import pal.tree.*;
import pal.io.*;

import java.io.*;


/**
 * reads a treefile (NH format) and reroots the tree
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
public class Reroot
{
	/**
	 * Usage: reroot node treefile outfile
	 *
	 * @param args command line options (node treefile outfile)
	 */
	public static void main(String[] args)
	{
		MacintoshCommandLine.getArguments(args);
		
		PrintWriter out;
	
		try
		{
			int num = Integer.parseInt(args[0]);
			ReadTree tree = new ReadTree(args[1]);
			
			out = OutputTarget.openFile(args[2]);
			
			tree.reroot(num);

			TreeUtils.printNH(tree, out);
			out.println();			
			tree.report(out);
			
			out.close();
		}
			catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Usage: reroot node treefile outfile");
			}
			catch (IOException e)
			{
				System.out.println("Error: File not found (IO error)");
			}
			catch (TreeParseException e)
			{
				System.out.println("Error: Parsing problem");
			}
			catch (Exception e)
			{
				System.out.println(e);
			}
	}
 }
