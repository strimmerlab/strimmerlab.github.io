// MLDist.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)

package vanilla.cui;

import pal.alignment.*;
import pal.datatype.*;
import pal.distance.*;
import pal.io.*;
import pal.substmodel.*;
import pal.misc.*;
import pal.eval.*;
import pal.tree.*;

import java.io.*;


/**
 * computes observed and maximum likelihood distances from sequences
 *
 * @version $Id: $
 *
 * @author Korbinian Strimmer
 */
public class MLDist
{
	/**
	 * Usage: mldist 
	 *
	 * @param args command line options ()
	 */
	public static void main(String[] args)
	{
		System.out.println();
		System.out.println();
		System.out.println("Welcome to MLDIST (" + ReleaseInfo.VERSION + ")!");
		System.out.println();
		System.out.println();

		// Read data set
		String indataName;
		if (args.length == 0)
		{
			indataName = "indata";
		}
		else
		{
			indataName = args[0];
		}
		
		System.out.println();
		System.out.println();
		System.out.println("Reading input alignment (" + indataName + ")");
		
		PushbackReader in;
		in = FileIO.openIn(indataName);
		Alignment raw = null;
		try
		{
			raw = new ReadAlignment(in);
		}
		catch (AlignmentParseException e)
		{
			System.out.println("Error: Alignment parsing problem");
			System.exit(1);
		}
		catch (IOException e)
		{
			System.out.println("Error: File not found (IO error)");
			System.exit(1);
		}	
		FileIO.close(in);
		
		System.out.println();
		System.out.println("Contains " + raw.numSeqs + " sequences of length " + raw.numSites);
		System.out.println("Likely content: " + raw.dataType.getDescription() + " data");
		System.out.println();
		

		// Set options
		Options options = new Options();
		options.setMLDIST();
		options.dtyp = raw.dataType.getTypeID();
		if (options.dtyp == 1)
		{
			options.smodel = AminoAcidModel.getSuitableModelID(raw.frequency);
		}
		options.setOptions();
		
		
		// Start computation
		TimeStamp timeStamp = new TimeStamp();

		// Compute distances
		raw.dataType = DataType.getInstance(options.dtyp);
		
		SitePattern sitePattern = new SitePattern(raw);
		
		DistanceMatrix mat = null;
		
		System.out.println();
		System.out.println("Computing distance matrix");
		
		SubstitutionModel model = null;
		if (options.useModel)
		{
			// create model
			double[] modelFreq;
			if (options.userFreqs)
			{
				modelFreq = options.freq;
			}
			else
			{
				raw.estimateFrequencies();
				modelFreq = raw.frequency;
			}
			RateMatrix rmat = RateMatrix.getInstance(options.dtyp, options.smodel,
				options.params, modelFreq);
			RateDistribution rdist = null;
			if (options.rmodel == 0) rdist = new UniformRate();
			if (options.rmodel == 1) rdist = new GammaRates(options.alphaCats, options.alpha);	
			if (options.rmodel == 2) rdist = new InvariableSites(options.fracInv);	
			model = new SubstitutionModel(rmat, rdist);	
		
			// estimate model parameters
			if (options.optModel && model.getNumParameters() > 0)
			{
				System.out.println("Optimising model parameters");
				ModelParameters mp = new ModelParameters(sitePattern, model);
				mp.estimate();
				mp = null;
			}

			mat = new AlignmentDistanceMatrix(sitePattern, model);
		}
		else mat = new AlignmentDistanceMatrix(sitePattern);

		SimpleTree tree;
		if (options.treeMethod == 0)
		{
			System.out.println("Computing NJ tree");
			tree = new NeighborJoiningTree(mat);
		}
		else
		{
			System.out.println("Computing UPGMA tree");
			tree = new UPGMATree(mat);
		}
		
		
		
		SimpleTree[] btrees = null;
		if (options.numBootstraps > 0)
		{
			BootstrappedAlignment bal = new BootstrappedAlignment(raw);
			SitePattern bsp = null;
			AlignmentDistanceMatrix adm = null;
			btrees = new SimpleTree[options.numBootstraps];
			
			System.out.println("Bootstrapping and recomputing distance matrix and tree");
			for (int i = 0; i < options.numBootstraps; i++)
			{
				System.out.println("Repeat #" + (i+1));
				bal.bootstrap();
				bsp = new SitePattern(bal);
				if (i == 0)
				{
					if (options.useModel)
						adm = new AlignmentDistanceMatrix(bsp, model);
					else
						adm = new AlignmentDistanceMatrix(bsp);
				}
				else
				{
					adm.recompute(bsp);
				}

				if (options.treeMethod == 0)
				{
					btrees[i] = new NeighborJoiningTree(adm);
				}
				else
				{
					btrees[i] = new UPGMATree(adm);
				}

			}
			bsp = null;
		}
		
		
		timeStamp.stop();

		System.out.println("Saving to disk (outfile, outdist, outtree)");

		try
		{
			PrintWriter out = OutputTarget.openFile("outfile"); 			
			
			out.println("MLDIST (" + ReleaseInfo.VERSION + ")");
			out.println();
			timeStamp.report(out);
			out.println();
			out.println();
			out.println("DATA SET");
			out.println();
			raw.report(out);
			out.println();
			out.println();
			
			if (options.useModel)
			{
				out.println("SUBSTITUTION MODEL");
				out.println();
				model.report(out);
				out.println();
				out.println();
				out.println("MAXIMUM LIKELIHOOD DISTANCES");
			}
			else
			{
				out.println("OBSERVED DISTANCES");
			}
			out.println();
			mat.printPHYLIP(out);
			
			out.println();
			out.println();
			if (options.treeMethod == 0)
			{
				out.println("NEIGHBOR JOINING TREE");
			}
			else
			{
				out.println("UPGMA TREE");
			}
			out.println();
			TreeUtils.printNH(tree, out);
			out.println();
											
			tree.report(out);
			out.println();
			
			if (options.numBootstraps > 0)
			{
				out.println();
				out.println("BOOTSTRAP PRECEDURE");
				out.println();
				out.println("Number of bootstraps: " + options.numBootstraps);
				out.println();
				out.println("Bootstrap trees are written to disk (bootstrap-trees)");
				out.println();
			}
	
			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outfile could not be created (IO error)");
			System.exit(1);
		}
		
		try
		{
			PrintWriter out = OutputTarget.openFile("outdist");
			
			mat.printPHYLIP(out);

			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outdist could not be created (IO error)");
			System.exit(1);
		}

		try
		{
			PrintWriter out = OutputTarget.openFile("outtree");
			
			TreeUtils.printNH(tree, out);

			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outtree could not be created (IO error)");
			System.exit(1);
		}

		if (options.numBootstraps > 0)
		{
			System.out.println("Saving to disk (bootstrap-trees)");
	
			try
			{
				PrintWriter out = OutputTarget.openFile("bootstrap-trees");
			
				for (int i = 0; i < options.numBootstraps; i++)
					TreeUtils.printNH(btrees[i], out);

				out.close();
			}
			catch (IOException e)
			{
				System.out.println("Error: bootstrap-trees could not be created (IO error)");
				System.exit(1);
			}
		}


		System.out.println();


	}
 }
