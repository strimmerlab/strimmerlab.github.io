// Evolve.java
//
// (c) 1999-2000 Korbinian Strimmer
//
// This package may be distributed under the
// terms of the GNU General Public License (GPL)


package vanilla.cui;

import pal.alignment.*;
import pal.datatype.*;
import pal.io.*;
import pal.substmodel.*;
import pal.misc.*;
import pal.eval.*;
import pal.tree.*;

import java.io.*;


/**
 * generates artifical data sets given a tree and a model of substitution
 *
 * @version $Id:$
 *
 * @author Korbinian Strimmer
 */
public class Evolve
{
	/**
	 * Usage: evolve 
	 *
	 * @param args command line options ()
	 */
	public static void main(String[] args)
	{
		System.out.println();
		System.out.println();
		System.out.println("Welcome to EVOLVE (" + ReleaseInfo.VERSION + ")!");
		System.out.println();
		System.out.println();

		
		// Read tree
		System.out.println();
		System.out.println();
		System.out.println("Reading input tree (intree)");
		PushbackReader in = FileIO.openIn("intree");
		SimpleTree tree = null;
		try
		{		
			tree = new ReadTree(in); 
		}
		catch (TreeParseException e)
		{
			System.out.println("Error: Tree parsing problem");
			System.exit(1);
		}
		FileIO.close(in);	


		// Set options
		Options options = new Options();
		options.setEVOLVE();
		options.setOptions();
		
		if (options.userFreqs != true)
		{
			System.out.println();
			System.out.println("ERROR: Frequencies not specified!");
			System.out.println();
			System.exit(1);
		}
				
		// Start computation
		TimeStamp timeStamp = new TimeStamp();		
				
		// create model
		RateMatrix rmat = RateMatrix.getInstance(options.dtyp, options.smodel,
			options.params, options.freq);
		RateDistribution rdist = null;
		if (options.rmodel == 0) rdist = new UniformRate();
		if (options.rmodel == 1) rdist = new GammaRates(options.alphaCats, options.alpha);	
		if (options.rmodel == 2) rdist = new InvariableSites(options.fracInv);	
		SubstitutionModel model = new SubstitutionModel(rmat, rdist);	

		SimulatedAlignment sim = new SimulatedAlignment(options.numSites, tree, model);
			
		timeStamp.stop();

		System.out.println();
		System.out.println("Writing results to disk (outfile, outdata)");
		System.out.println();
		
		try
		{
			PrintWriter out = OutputTarget.openFile("outfile");
			
			out.println("EVOLVE (" + ReleaseInfo.VERSION + ")");
			out.println();
			timeStamp.report(out);
			out.println();

			out.println("SUBSTITUTION MODEL");
			out.println();
			model.report(out);
			out.println();
			out.println();

			out.println("EVOLUTIONARY TREE");
			out.println();
			tree.report(out);
			out.println();
			out.println();

			out.println("GENERATED DATA (outdata)");
			out.println();
			out.println("Number of data sets: " + options.numDataSets);
			out.println("Sequence length: " + options.numSites);
			out.println();
			
			out.close();
			
			System.out.println("Generating data sets");
			
			out = OutputTarget.openFile("outdata");
			
			for (int i = 0; i < options.numDataSets; i++)
			{
				sim.simulate();
				sim.print(out);
				out.println();
			}
			
			out.close();
		}
		catch (IOException e)
		{
			System.out.println("Error: outfile could not be created (IO error)");
			System.exit(1);
		}
		
	}
 }
