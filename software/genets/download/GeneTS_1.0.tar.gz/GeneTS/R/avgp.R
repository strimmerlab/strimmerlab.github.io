### avgp.R  (2003-06-17)
###
###    Average periodogram and related stuff
###
### Copyright 2003 Korbinian Strimmer and Konstantinos Fokianos
###
### This file is part of the `GeneTS' library for R and related languages.
### It is made available under the terms of the GNU General Public
### License, version 2, or at your option, any later version,
### incorporated herein by reference.
### 
### This program is distributed in the hope that it will be
### useful, but WITHOUT ANY WARRANTY; without even the implied
### warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
### PURPOSE.  See the GNU General Public License for more
### details.
### 
### You should have received a copy of the GNU General Public
### License along with this program; if not, write to the Free
### Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
### MA 02111-1307, USA



# periodogram  of a single time series x
periodogram.spec.single <- function(x, method="builtin")
{
    if (method=="builtin")
    {
      # demean but do not detrend to avoid artefacts around zero
      spec <- spectrum(x, taper=0, plot=FALSE, fast=FALSE, detrend=FALSE, demean=TRUE)$spec
    } 
    else if (method =="xfft")
    {
       x <- x - mean(x) # demean
       
       N<-length(x)
       xfft <- fft(x)
       #pgram <- (Mod(xfft)^2/(2*pi*N))
       pgram <- (Mod(xfft)^2/(N))  # to make ordinate as in spectrum
       #pgram <- Re(xfft*Conj(xfft)/(N )) #this is the same 
       
       spec <- pgram[1 + (1:floor(N/2)) ] 
    }
    else if (method =="smooth")
     {
      # demean but do not detrend to avoid artefacts around zero
      spec <- spectrum(x, taper=0, plot=FALSE, fast=FALSE, detrend=FALSE, demean=TRUE, span=3)$spec
    } 
   
    spec
}


# periodogram  of multiple time series x
periodogram.spec <- function(x, method="builtin")
{
     if (is.matrix(x) == FALSE) # only one time series
     {
       return(periodogram.spec.single(x, method=method))
     } 
     else
     {     
       f <- periodogram.freq(x[1,])
       spec.matrix <- matrix(NA, nrow=dim(x)[1], ncol=length(f))
       for (i in 1:dim(x)[1])
       {
          spec.matrix[i,] <- periodogram.spec.single(x[i,], method=method)
       }
       return(spec.matrix)
     }
}

 
# corresponding frequencies (0..pi)
periodogram.freq <- function(x, ...)
{
    if (is.matrix(x) == TRUE)
      z <- x[1,]   # use first time series
    else
      z <- x

    z.spec <- periodogram.spec(z, ...)
    delta <- 0.5/length(z.spec)
    
    2*pi*seq(delta, 0.5, delta)
}


# Average Periodogram:
avgp <- function(x, title="untitled", plot=TRUE, ...)
{
    f <- periodogram.freq(x[1,], ...)    
    spec.matrix <- periodogram.spec(x, ...)
    avg.spec <- apply(spec.matrix,2,mean)
    out = list(freq=f, avg.spec=avg.spec, title=title)
    
    if (plot)
    {
        plot(out[[1]], out[[2]],  type="l", 
        xlab="Fourier Frequencies", ylab="Average Periodogram", ...)
        title(main=title)
	
        return(invisible(out))
    }
    else return(out)  
}


# returns back the m dominant frequencies in single time series periodogram
dominant.freqs.single <- function(x, m=1, ...)
{    
    Period.spec <- periodogram.spec(x, ...) 
    Period.freq <- periodogram.freq(x)
    
    sorted.freqs <- Period.freq[order(-Period.spec)]
    
    sorted.freqs[1:m]
}


# dito, but now also for multiple time series
dominant.freqs <- function(x, m=1, ...)
{
     if (is.matrix(x) == FALSE) # only one time series
     {
       return(dominant.freqs.single(x, m=m, ...))
     } 
     else
     {
       freq.matrix   <- matrix(NA, nrow=dim(x)[1], ncol=m)
       for (i in 1:dim(x)[1])
       {
          freq.matrix[i,] <- dominant.freqs.single(x[i,], m=m, ...)
       }
       return(freq.matrix)
     }
}


