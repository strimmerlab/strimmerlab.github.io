
.First.lib <- function(lib, pkg) {
    
  cat("\n\n\n")
  cat("-----------------------------------------------------------------\n")
  cat("With the present version, GeneTS has become a meta-package that\n")
  cat("exists mainly for reasons of backward compatibility.\n")
  cat("\n")
  cat("Its only purpose is to load the GeneCycle and GeneNet packages.\n")
  cat("You may load either of these packages directly.\n")
  cat("-----------------------------------------------------------------\n")
  cat("\n\n\n")
}

