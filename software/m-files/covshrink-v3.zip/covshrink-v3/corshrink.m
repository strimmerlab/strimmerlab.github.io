function r = corshrink (x)
% corshrink(x) estimates the correlation matrix using a 
% shrinkage approach described in Schaefer and Strimmer (2005). 
% In this approach, the empirical correlation matrix is shrunk
% towards the identity matrix, and the optimal shrinkage intensity
% is estimated by an analytic formula.
% The input matrix x is a n x p data matrix, and
% the output matrix is a p x p correlation matrix.
%
% Last modified: 21 March 2006
%
 
  if (ndims(x) ~= 2)
    error ('corshrink: x must be a matrix');
  end

  [n,p] = size(x);

  if (n == 1)
    error ('corshrink: number of rows in x (=sample size) must be large than 1');
  end
 
  if (p == 1) % if p = 1 we are done already
    r = [1];
    return;    
  end
    
  % estimate variance of empirical correlation coefficients 
  sx = centermat(x, true);  % standardize data
  [s, vs] = varcov(sx, false);
  
  % find optimal shrinkage intensity lambda   
  offdiagsumrij2 = sum(sum(tril(s,-1).^2));  % elementwise multiplication
  offdiagsumvrij = sum(sum(tril(vs,-1)));
  lambda = offdiagsumvrij/offdiagsumrij2;
 
  fprintf(1, 'Estimated shrinkage intensity (correlation matrix):  %5.4f\n', lambda);
  
  
  %%%%%%%%%
  
  if (lambda > 1)
    warning('Overshrinking: intensity set to 1 (allowed range: 0-1)');
    lambda = 1;  
  end
  
  if (lambda < 0)
     warning('Undershrinking: intensity set to 0 (allowed range: 0-1)');
     lambda = 0;  
  end


  %%%%%%%%%
 
  % construct shrinkage estimator
  r = (1-lambda)*s;
  for i = 1:p
    r(i,i) = 1;
  end
 
end
