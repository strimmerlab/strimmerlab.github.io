function sv = varshrink (x)
% varshrink(x) estimates the vector of variances by shrinking the
% variances against the median of the empirical variances -
% see Opgen-Rhein and Strimmer (2006) for details.
%
% The input matrix x is a n x p data matrix, and
% the output matrix is a vector of length p.
%
% Last modified: 17 July 2006
%
  
  if (ndims(x) ~= 2)
    error ('varshrink: x must be a matrix');
  end

  [n,p] = size(x);

  if (n == 1)
    error ('varshrink: number of rows in x (=sample size) must be large than 1');
  end
 
  if (p == 1) % if p = 1 we are done already
    sv = var(x);
    return;    
  end
    
  % center data
  cx = centermat(x, false); 
  
  % estimate variance of empirical correlation variances  
  [v, vv] = varcov(cx, true);
  
  vtarget = median(v);
  numerator = sum(vv);
  denominator = sum((v-vtarget).^2);
  lambda = numerator/denominator;
 
  fprintf(1, 'Estimated shrinkage intensity (variance vector):  %5.4f\n', lambda);
  
  
  %%%%%%%%%
  
  if (lambda > 1)
    warning('Overshrinking: intensity set to 1 (allowed range: 0-1)');
    lambda = 1;  
  end
  
  if (lambda < 0)
     warning('Undershrinking: intensity set to 0 (allowed range: 0-1)');
     lambda = 0;  
  end


  %%%%%%%%%
 
  % construct shrinkage estimator
  sv = (1-lambda)*v + lambda*vtarget;
 
end
