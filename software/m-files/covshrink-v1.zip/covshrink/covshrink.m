function s = covshrink (x)
% covshrink(x) estimates the covariance matrix using a shrinkage approach. 
% The input matrix x is a n x p data matrix, and
% the output matrix is a p x p covariance matrix.
% See Schaefer and Strimmer (2005) for details.

   
  if (ndims(x) ~= 2)
    error ('covshrink: x must be a matrix');
  end

  [n,p] = size(x);

  if (n == 1)
    error ('covshrink: number of rows in x (=sample size) must be large than 1');
  end
  

  % compute unbiased variances  
  v = var(x);
  dsv = diag(sqrt(v));
  
  % then compute shrinkage estimate of correlation
  r = corshrink(x);
   
  % join the two pieces together
  s = dsv*r*dsv;

end




