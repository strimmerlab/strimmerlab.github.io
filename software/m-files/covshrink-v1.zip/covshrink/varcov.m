function [s, vs] = varcov(x)
% varcov(x) compute the unbiased empirical covariance matrix s=cov(x)
% as well as the variances vs of each matrix entry of s.
% The input matrix has dimensions n x p, the output matrics
% s and vs are both of size p x p.

  if (ndims(x) ~= 2)
    error ('varcov: x must be a matrix');
  end

  [n,p] = size(x);

  if (n == 1)
    error ('varcov: number of rows in x (=sample size) must be large than 1');
  end

  h1 = 1/(n-1);
  h2 = n/(n-1)/(n-1);
  
  s = zeros(p, p);   
  vs = zeros(p, p);
  xc = centermat(x, false); % center the data
    
  % diagonal elements
  for i = 1:p
    zii     = xc(:,i).^2;   % vector of squared entries of column i
    s(i,i)  = sum(zii)*h1;
    vs(i,i) = var(zii)*h2;
  end
      
  if (p == 1)
    return;
  end
  
  if (p > 50)
      page_screen_output = 0;
      fprintf(1, 'Computing ... wait for %d dots (50 per row):\n', p);
  end
   
  % off-diagonal elements
  for i = 1:(p-1)
    
    if (p > 50)
      fprintf(1, '.');
      if (rem(i,50) == 0) 
        fprintf(1, '  %d\n', i);
      end  
    end
      
    for j = (i+1):p
      zij     = xc(:,i).*xc(:,j); % elementwise multiplication 
      s(i,j)  = sum(zij)*h1;
      s(j,i)  = s(i,j);
      vs(i,j) = var(zij)*h2;
      vs(j,i) = vs(i,j);
    end
      
  end
  if (p > 50)
    fprintf(1, '.  %d\n', i+1);
    page_screen_output = 1;
  end
 
end


