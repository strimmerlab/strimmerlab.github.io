function xc = centermat(x, standardize)
% centermat(x, false) centers the matrix x.
% The column means of the resulting matrix are zero.
% centermat(x, true) additionally standardizes the matrix x,
% i.e. it makes all column variances equal to one.
%
% Last modified: 27 November 2005
%

  if (ndims(x) ~= 2)
    error ('ctrmat: x must be a matrix');
  end

  [n,p] = size(x);

  if (n==1)
    if(standardize)
      error ('stdmat: number of rows in x (=sample size) must be large than 1');
    else
      xc = zeros(1, p);
      return;  
    end
  end
      
  m = mean(x);
  xc = x - ones(n, 1)*m; % center
  
  if (~standardize)
    return;
  end

  vx = var(x); 
  sd = ones(n, 1)*sqrt(vx);
  xc = xc ./ sd; % elementwise division

end
