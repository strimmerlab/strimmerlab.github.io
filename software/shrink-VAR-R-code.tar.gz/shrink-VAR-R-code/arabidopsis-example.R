# 2007 Rainer Opgen-Rhein
# License: GNU GPL 2 or later


# example script for estimationg an Arabidopis VAR network 

# see for methodological details:
# R. Opgen-Rein and K. Strimmer. 2007. Learning causal networks 
# from systems biology time course data: an effective model 
# selection procedure for the vector autoregressive process. 
# BMC Bioinformatics 8 Suppl. 2: S3.


library("GeneNet") # version 1.2 or later
  
# load functions for estimating shrinkage VAR model
source("mvr.shrink.R") # define mvr.shrink function
source("shrink.VAR.R") 
  
# functions for plotting the resulting VAR network
source("makedotfile.VAR.R")


#################################################################

# load Arabidopsis thaliana data set
data("arth800")
  

################# estimate VAR coefficients ##################### 

# input: n x p data matrix, has to be of type "longitudinal",
# output:  
#  B_est: estimated VAR regression coefficients
#  r.mat: corresponding partial correlations for B_est
#  l.est: shrinkage parameter for correlations
#  l.var.est: shrinkage parameter for variance vector

VAR.coeff <- shrink.VAR(arth800.expr)

names(VAR.coeff)
# "B_est"      "r.mat"      "lambda"     "lambda.var"

# assign local fdr values to each edge (prob=1-local fdr)
results.VAR <- test.VAR(VAR.coeff)
 
# determine significant edges (local fdr < 0.2)
results.sig <- results.VAR[results.VAR$prob > 0.80,]
dim(results.sig)[1] # number of significant edges

######### plot VAR network ######################################

# generate dot file for plotting with graphviz

# restrict to top 150 edge 
makedotfile_VAR(results.VAR[1:150,], "VAR.dot") 

# include all significant edges 
#makedotfile_VAR(results.sig, "VAR.dot") 

# use "fdp" layout algorithm of graphviz
system("fdp -T png -o VAR.png VAR.dot")

# For the above system() command to work it is necessary that
# the graphviz command tools are in the appropriate path.
# Alternativel, you may wisht to run a GUI frontend to graphviz 
# to process the VAR.dot file.
