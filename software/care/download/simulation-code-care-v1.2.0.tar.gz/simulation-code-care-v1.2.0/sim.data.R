
# 1 June 2010

# some routines to simulate data 

# from multinormal distribution: sim.mvnorm
# from linear model: sim.lm.data


########################################
# simulate multivariate normal data
# n:   sample size
# mu:  mean
# sd:  standard deviation
# cR:  chol(R)
########################################

sim.mvnorm = function(n, mu, sd, cR)
{
   retval = matrix(rnorm(n * ncol(cR)), nrow = n) # independent unit normal
   retval = retval %*% cR                         # correlation
   retval = sweep(retval, 2, sd, "*")             # scale
   retval = sweep(retval, 2, mu, "+")             # location

   return(retval)
}

###############################################################
# simulate data (Y,X) according to linear model Y=beta*X + Eps
# n:     sample size
# beta:  regression coefficients 
# cR:    chol(R) correlation among predictors
# sdX:   standard deviation of predictors
# sdEps: standard deviation of noise term
###############################################################

sim.lm.data = function(n, beta, cR, sdX, sdEps)
{
  p = length(beta)

  # simulate X, then generate Y

  mu = rep(0, p)
  X = sim.mvnorm(n, mu, sdX, cR)  # dim(X): n x p 
  Y = X %*% beta + rnorm(n, mean=0, sd=sdEps)
 
  colnames(X) = paste(c("X"), 1:p, sep="")
  colnames(Y) = "Y"

  return( list(Y=Y, X=X) )
}

