
The R scripts in this directory allow to reproduce the simulations
of Zuber and Strimmer (2011). 

Please install the following packages from CRAN:

 scout
 glasso
 lars
 care
 corpcor

Then open the file "main-sim.R" and run the R code.


For computing cross-validation estimates install the "crossval" package
from CRAN and then run the code in the file "main-cv.R".


