# 25 June 2010
# 29 March 2014 updated for crossval




# estimate prediction error using cross-validation
lmprederr.cv = function(Xtrain, Ytrain,
                       K=10,  # number of folds
                       B=20,  # number of repetitions
                       ... )
{
  # function to learn linear model, predict, and compute prediction error
  lmprederr.fun = function(Xtrain, Ytrain, Xtest, Ytest, ...)
  {
    coeff = lmcoeff(Xtrain, Ytrain, ...)
    Ynew = lmpredict(coeff, Xtest)
    prederr = mean( (Ynew - Ytest)^2)  # squared error risk

    return(prederr)  
  }


  cv.out = crossval(lmprederr.fun, Xtrain, Ytrain, K=K, B=B, ...)

  return( cv.out ) 
}

# return lambda with lowest estimated crossvalidation error
bestlambda.cv = function(Xtrain, Ytrain, 
                          K=10,  # number of folds
                          B=20,  # number of repetitions
                          lambdas,
                         ...)
{
  lambdas = as.matrix(lambdas)
  perr.val = numeric(dim(lambdas)[1])

  for (i in 1:length(perr.val))
  { 
    #cat("Computing prediction error #", i, "of", length(perr.val), "\n")
    perr.val[i] = lmprederr.cv(Xtrain, Ytrain, K=K, B=B, lambda=lambdas[i,], ...)$stat[1]
  }
  min.idx = which.min(perr.val)[1]

  return( lambdas[min.idx,] )
}

