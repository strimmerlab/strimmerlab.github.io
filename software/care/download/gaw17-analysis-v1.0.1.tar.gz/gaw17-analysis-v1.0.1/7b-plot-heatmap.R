#
# 22 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#

# generate heatmap plots (Fig. 2)


# Read data
########################################################################


ROOT="rda"

# Read data
load(file=paste(ROOT, "/workingdata.rda", sep=""))

load(file=paste(ROOT, "/Q1.hits.rda", sep=""))
load(file=paste(ROOT, "/Q2.hits.rda", sep=""))


########################################################################
# 		Q1						       #
######################################################################## 


# recover names of the true positive SNPs 
########################################################################

idQ1 = which(id.TPQ1==TRUE)			#which SNPs are TP (in 1:8020)

#snpInfo[unlist(x.map[idQ1] [1]),]		#SNPs that make up the first TP profile

table.id=matrix(nrow=38, ncol=2)		
for(i in 1:38){
table.id[i,]=which(trueQ1[,2]%in%rownames(snpInfo[unlist(x.map[idQ1] [i]),]) == TRUE)
}


i=1
which(trueQ1[,2]%in%rownames(snpInfo[unlist(x.map[idQ1] [i]),]) == TRUE)
# SNP  31 and 36  in trueQ1 join the same profile


tab.id = table.id[,1]
t.Q1 = trueQ1[tab.id,]


# edit and concatenate SNP and gene name 
########################################################################

SNP.tQ1 = t.Q1[,2]
gene.tQ1 = t.Q1[,1]
l.gene = nchar(as.character(gene.tQ1))
name.tQ1 = vector(length=38)

for(i in 1:38){
  fill.sp = 7-l.gene[i]
  fill.char = paste(character(fill.sp), collapse=" ")
  gene.name = paste(gene.tQ1[i],  fill.char, sep="")
  name.tQ1[i] = paste(gene.name,  SNP.tQ1[i], sep="| ")
}

#name.tQ1
# [1] "ARNT  | C1S6537"  "HIF1A | C14S1718" "KDR   | C4S1887"  "HIF1A | C14S1736"
# [5] "FLT4  | C5S5156"  "KDR   | C4S1873"  "ELAVL4| C1S3181"  "ELAVL4| C1S3182" 
# ....



colnames(Q1.hits)=name.tQ1




# sort after car score
########################################################################

idQ1car=sort(Q1.hits[1,], index.return=TRUE)
Q1.pl = Q1.hits[,idQ1car$ix]
Q1.pl[1,]

# plot heatmap
########################################################################

#breaks = c(0,10,40,70,100,130,160,190,200)
#col=c("grey95","grey90", "grey80","grey70","grey40", "grey30","grey20", "grey10")


breaks = c(0,10,50,100,150,190,200)
col=c("grey99","grey90", "grey70", "grey40","grey25", "grey10")


pdf(width=10, height=10, file="plots/Q1heatmap.pdf")
 heatmap(t(Q1.pl), col=col, breaks=breaks, scale="none",  Colv = NA, Rowv= NA, mar=c(12,7), add.expr=TRUE,
main="Q1")
library(fields)
image.plot(zlim=c(0,200), legend.only=TRUE, legend.shrink = 1, horizontal=TRUE, col=col, breaks=breaks,
axis.args=list(at=breaks, labels=breaks), legend.width=1.2)
dev.off()



########################################################################
# 		Q2						       #
######################################################################## 


# recover names of the true positive SNPs 
########################################################################

idQ2 = which(id.TPQ2==TRUE)			#which SNPs are TP (in 1:8020)



table.id=matrix(nrow=71, ncol=2)		
for(i in 1:71){
table.id[i,]=which(trueQ2[,2]%in%rownames(snpInfo[unlist(x.map[idQ2] [i]),]) == TRUE)
}




i=25
which(trueQ2[,2]%in%rownames(snpInfo[unlist(x.map[idQ2] [i]),]) == TRUE)
# SNP  2 and 38 in trueQ2 join the same profile


tab.id = table.id[,1]
t.Q2 = trueQ2[tab.id,]


# edit and concatenate SNP and gene name 
########################################################################


SNP.tQ2 = t.Q2[,2]
gene.tQ2 = as.character(t.Q2[,1])
l.gene = nchar(gene.tQ2)

name.tQ2 = vector(length=71)

for(i in 1:71){
  fill.sp = 7-l.gene[i]
  fill.char = paste(character(fill.sp), collapse=" ")
  gene.name = paste(gene.tQ2[i],  fill.char, sep="")
  name.tQ2[i] = paste(gene.name,  SNP.tQ2[i], sep="| ")
}

#name.tQ2
# [1] "PLAT  | C8S1742"  "SREBF1| C17S1009" "VLDLR | C9S391"   "SIRT1 | C10S3109"
# [5] "BCHE  | C3S4867"  "VNN3  | C6S5412"  "VNN3  | C6S5448"  "VNN3  | C6S5439" 
# ...

colnames(Q2.hits)=name.tQ2


# sort after car score
########################################################################


idQ2car=sort(Q2.hits[1,], index.return=TRUE)
Q2.pl = Q2.hits[,idQ2car$ix]
Q2.pl[1,]


# plot heatmap
########################################################################

#breaks = c(0,10,40,70,100,130,160,190,200)
#col=c("grey95","grey90", "grey80","grey70","grey40", "grey30","grey20", "grey10")


breaks = c(0,10,50,100,150,190,200)
col=c("grey99","grey90", "grey70", "grey40","grey25", "grey10")


pdf(width=10, height=11, file="plots/Q2heatmap.pdf")
 heatmap(t(Q2.pl), col=col, breaks=breaks, scale="none",  Rowv = NA, Colv=NA, mar=c(5,7), main="Q2")
dev.off()


