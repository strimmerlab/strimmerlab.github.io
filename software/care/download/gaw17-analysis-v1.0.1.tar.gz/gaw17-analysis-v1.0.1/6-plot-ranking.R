#
# 22 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#

# generate ranking plots (Fig. 1) and associated table (Tab. 1)


ROOT="."

# Read data
load(file=paste(ROOT, "/rda/workingdata.rda", sep=""))


######################################
# find cumulative number of true positives

# cumulative number of true positives (single run)
tp.counts = function( stat, tp)
{
  if (length(tp) != length(stat)) stop("arguments must have same length")
  
  # randomize order (to avoid using input order for vanishing coefficients) 
  shuffle = sample(length(tp)) 
  stat = stat[shuffle]
  tp = tp[shuffle]
	
  # sort statistics in decreasing magnitude
  ostat =  order(abs(stat), decreasing=TRUE)

  # cumulative true positives
  tp.counts = cumsum(tp[ostat])

  return(tp.counts)
}

# average cumulative number of true positives (accross all runs)
avg.tp.counts = function( stat.mat, tp)
{
  B = dim(stat.mat)[1]

  avg.tp.count = numeric(dim(stat.mat)[2])
  for( i in 1:B)
    avg.tp.count = avg.tp.count + tp.counts(stat.mat[i,], tp) 
  avg.tp.count = avg.tp.count/B

  return(avg.tp.count)
}



########################################


mycol = list(
 lty=c(1,1, 2, 2, 4, 4, 3),
 col=c("black", "grey60", "black", "grey60", "black", "grey60", "grey60"),
 pch=c(19,19,19,19,19,19,NA),
 lwd=c(2,2, 2,2,2,2,2)
)


makeplot = function(idx, info=FALSE, main="")
{
  plot(TP.CAR[idx], type="l", col=mycol$col[1], lty=mycol$lty[1], 
   ylim=c(0,max(TP.CAR[idx])), lwd=mycol$lwd[1],
   xlab="No. of SNPs included", ylab="No. of true positive hits", 
   main=main)

  lines(TP.COR[idx], col=mycol$col[2], lty=mycol$lty[2], lwd=mycol$lwd[2])
  lines(TP.NEG[idx], col=mycol$col[3], lty=mycol$lty[3], lwd=mycol$lwd[3])  
  lines(TP.MCP[idx], col=mycol$col[4], lty=mycol$lty[4], lwd=mycol$lwd[4])
  lines(TP.BOOST[idx],  col=mycol$col[5], lty=mycol$lty[5], lwd=mycol$lwd[5])
  lines(TP.LASSO[idx], col=mycol$col[6], lty=mycol$lty[6],lwd=mycol$lwd[6]) 
  lines(TP.RND[idx], col=mycol$col[7], lty=mycol$lty[7], lwd=mycol$lwd[7])

  if(info) 
    legend(x="bottomright", 
      col=mycol$col,
      legend=c("CAR", "COR", "NEG", "MCP", "BOOST", "LASSO", "RND"),
      lty=mycol$lty,
      lwd=mycol$lwd,
      box.col=0,
      cex=.8
     )
}

########################################
# Q1

load(file=paste(ROOT, "/rda/CAR.Q1.rda", sep=""))
load(file=paste(ROOT, "/rda/COR.Q1.rda", sep=""))
load(file=paste(ROOT, "/rda/NEG.Q1.rda", sep=""))
load(file=paste(ROOT, "/rda/MCP.Q1.rda", sep=""))
load(file=paste(ROOT, "/rda/BOOST.Q1.rda", sep=""))
load(file=paste(ROOT, "/rda/LASSO.Q1.rda", sep=""))
load(file=paste(ROOT, "/rda/RND.Q1.rda", sep=""))


# ranking plot for Q1
TP.RND = avg.tp.counts(RND.Q1, id.TPQ1)
TP.COR = avg.tp.counts(COR.Q1, id.TPQ1)
TP.CAR = avg.tp.counts(CAR.Q1, id.TPQ1)
TP.BOOST = avg.tp.counts(BOOST.Q1, id.TPQ1)
TP.LASSO = avg.tp.counts(LASSO.Q1, id.TPQ1)
TP.NEG = avg.tp.counts(NEG.Q1, id.TPQ1)
TP.MCP = avg.tp.counts(MCP.Q1, id.TPQ1)


pdf(width=8, height=4.5, file="plots/rankingQ1.pdf")
par(mfrow=c(1,2))
makeplot(1:8020, info=TRUE, main="Q1 Ranking (All SNPs)")
makeplot(1:300, main="Q1 Ranking (Top 300 SNPs)")
par(mfrow=c(1,1))
dev.off()


### cutoffs

thresh.CAR = 218
thresh.COR = 319
thresh.NEG = 1390
thresh.MCP = 20
thresh.BOOST = 53
thresh.LASSO = 37

c(thresh.CAR, TP.CAR[thresh.CAR], TP.CAR[thresh.CAR], TP.COR[thresh.CAR], TP.RND[thresh.CAR])
c(thresh.COR, TP.COR[thresh.COR], TP.CAR[thresh.COR], TP.COR[thresh.COR], TP.RND[thresh.COR])
c(thresh.NEG, TP.NEG[thresh.NEG], TP.CAR[thresh.NEG], TP.COR[thresh.NEG], TP.RND[thresh.NEG])
c(thresh.MCP, TP.MCP[thresh.MCP], TP.CAR[thresh.MCP], TP.COR[thresh.MCP], TP.RND[thresh.MCP])
c(thresh.BOOST, TP.BOOST[thresh.BOOST], TP.CAR[thresh.BOOST], TP.COR[thresh.BOOST], TP.RND[thresh.BOOST])
c(thresh.LASSO, TP.LASSO[thresh.LASSO], TP.CAR[thresh.LASSO], TP.COR[thresh.LASSO], TP.RND[thresh.LASSO])

#Method     Model Size   TP      TP-CAR TP-COR TP-RND 
#CAR           218      9.635    9.635  8.490  1.110
#COR           319      9.280   10.990  9.280  1.625
#NEG           1390    15.310   17.565 14.375  6.595 
#MCP           20       4.110    4.190  3.945  0.115 
#BOOST         53       5.835    5.905  5.495  0.250
#LASSO         37       5.185    5.205  4.890  0.175




########################################
# Q2

load(file=paste(ROOT, "/rda/RND.Q2.rda", sep=""))
load(file=paste(ROOT, "/rda/COR.Q2.rda", sep=""))
load(file=paste(ROOT, "/rda/CAR.Q2.rda", sep=""))
load(file=paste(ROOT, "/rda/BOOST.Q2.rda", sep=""))
load(file=paste(ROOT, "/rda/LASSO.Q2.rda", sep=""))
load(file=paste(ROOT, "/rda/NEG.Q2.rda", sep=""))
load(file=paste(ROOT, "/rda/MCP.Q2.rda", sep=""))


# ranking plot for Q2
TP.RND = avg.tp.counts(RND.Q2, id.TPQ2)
TP.COR = avg.tp.counts(COR.Q2, id.TPQ2)
TP.CAR = avg.tp.counts(CAR.Q2, id.TPQ2)
TP.BOOST = avg.tp.counts(BOOST.Q2, id.TPQ2)
TP.LASSO = avg.tp.counts(LASSO.Q2, id.TPQ2)
TP.NEG = avg.tp.counts(NEG.Q2, id.TPQ2)
TP.MCP = avg.tp.counts(MCP.Q2, id.TPQ2)

pdf(width=8, height=4.5, file="plots/rankingQ2.pdf")
par(mfrow=c(1,2))
makeplot(1:8020, info=TRUE, main="Q2 Ranking (All SNPs)")
makeplot(1:300, main="Q2 Ranking (Top 300 SNPs)")
par(mfrow=c(1,1))
dev.off()


### cutoffs

thresh.CAR = 135
thresh.COR = 19
thresh.MCP = 29
thresh.NEG = 1632
thresh.LASSO = 15
thresh.BOOST = 59

c(thresh.CAR, TP.CAR[thresh.CAR], TP.CAR[thresh.CAR], TP.COR[thresh.CAR], TP.RND[thresh.CAR])
c(thresh.COR, TP.COR[thresh.COR], TP.CAR[thresh.COR], TP.COR[thresh.COR], TP.RND[thresh.COR])
c(thresh.NEG, TP.NEG[thresh.NEG], TP.CAR[thresh.NEG], TP.COR[thresh.NEG], TP.RND[thresh.NEG])
c(thresh.MCP, TP.MCP[thresh.MCP], TP.CAR[thresh.MCP], TP.COR[thresh.MCP], TP.RND[thresh.MCP])
c(thresh.BOOST, TP.BOOST[thresh.BOOST], TP.CAR[thresh.BOOST], TP.COR[thresh.BOOST], TP.RND[thresh.BOOST])
c(thresh.LASSO, TP.LASSO[thresh.LASSO], TP.CAR[thresh.LASSO], TP.COR[thresh.LASSO], TP.RND[thresh.LASSO])

#Method     Model Size   TP      TP-CAR TP-COR TP-RND 
#CAR           135        6.885  6.885   6.195   1.250  
#COR           19.000     2.225  2.165   2.225   0.190
#NEG           1632.00   20.21  28.08   25.90   14.50   
#MCP           29.000     2.745  2.820   2.760   0.275
#BOOST         59.000     3.920  4.335   3.820   0.585
#LASSO         15.000     1.500  1.875   1.970   0.135


