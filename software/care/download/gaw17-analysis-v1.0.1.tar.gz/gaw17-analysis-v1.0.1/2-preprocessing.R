#
# 22 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#


 
# - recode SNP (additive model)
# - remove duplicates (24487 -> 15076 unique snp patterns)

# - unique SNP labels are now sorted to avoid inconsistencies
#   between Windows and Linux versions of R


load("rda/gaw17unrelated.rda")


########################################################################

# recode alleles into 0,1,2

countVariants = function(allele, variant)
{
  la = length(allele)
  counts = rep(0, la)

  for (i in 1:la)
  {
    a = strsplit(allele[i], "/")[[1]]
    counts[i] = sum(a == variant) 
  }

  return(as.character(counts))
}


############### example

# snp i=11
i = 11
snp.name = colnames(x)[i] # "C1S716"
# variant
v = snpInfo[snp.name,"variant"] # "T"
# alleles
a = levels(x[,snp.name]) # "C/C" "C/T" "T/C" "T/T"
# recoded version
countVariants(a, v) # "0" "1" "1" "2"

### recode complete data set

x.recode = matrix(0, nrow = dim(x)[1], ncol = dim(x)[2] )
colnames(x.recode) = colnames(x)
rownames(x.recode) = rownames(x)
for (i in 1:dim(x)[2])
{
  cat("recode snp #", i, "/", dim(x)[2], "\n")
  snp.name = colnames(x)[i]
  v = snpInfo[snp.name,"variant"] # variant
  f = x[,snp.name]
  a = levels(f) # alleles
  levels(f) = countVariants(a, v)
  x.recode[,i] = as.numeric(as.character(f))
}

dim(x.recode)
#[1]   697 24487
x.recode[1:10,1:20]

# standardize predictors
x.recode = scale(x.recode)

########################################################################

# find duplicates


# sum( duplicated(t(x.recode)) ) # 9411

v = vector(mode="character", length=24487)
for (i in 1:24487)
  v[[i]] = paste(x.recode[,i], collapse="" )
v.fac =  factor(v)
nv.fac = as.numeric( v.fac)
length ( levels( v.fac ) ) # 15076 = 24487-9411
range( nv.fac ) # 1  15076 


# find labels for unique snp patterns

# nv.fac could also be used as unsp labels, 
# but yields different results on Windows and Linux !
# to avoid ambiguities we therefore sort the nv.fac values
map2NEW = rep(0, 15076)
k=1
for (i in 1:length(nv.fac))
{
  m = nv.fac[i]
  if ( map2NEW[ m ] == 0 )
  {
    map2NEW[ m ] = k
    k = k+1
  }
}

# original snp (1-24487) -> unique snp pattern (1-15076)
# -> snp2usnp
snp2usnp = map2NEW[nv.fac]

snp2usnp[1:500]
#  [1]   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18
#..
# [487] 455 456 457 458 459 460 461 114 462 463  24 464 465 466


# unique snp (1-15076) -> orginal set of snps
usnp2snp = list(length=15076)
for (i in 1:15076)
{
  usnp2snp[[i]] = which( snp2usnp == i )
}


sum( table(snp2usnp) == 1 ) # 14096  number of truly unique snps
sum( table(snp2usnp) > 1 ) # 980 number of snp clusters

idx = as.numeric( sapply( usnp2snp, min))

x.usnp = x.recode[,idx]
colnames(x.usnp) = NULL
dim(x.usnp) # matrix 697 x 15076

# sum( duplicated(t(x.usnp)) ) # 0


## check that no abs(cor)==1

#cx.usnp = cor(x.usnp)
#Rxx.thresh = ifelse( abs(cx.usnp)>= 1, 1, 0)
#
#library("igraph")
#g = graph.adjacency(Rxx.thresh, mode="undirected")
#cl = clusters(g) 
#
#cl$no #15076

########################################################################

save(x.usnp, snp2usnp, usnp2snp, file="rda/preprocessed.rda")





