#
# 22 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#



# filter: synonymous SNPs are removed
# adjust for non-genetic covariates (sex, age, smoking)
# save: SNP data and x.map for indizes to snpInfo



load( "rda/gaw17unrelated.rda" )
load( "rda/preprocessed.rda" )


########################################################################


# filter: Use only Nonsynonymous unique SNPs

dim(snpInfo)
# 24487     6

head(snpInfo)
#       chromosome position         gene      snp_type variant      maf
#C1S672          1   845962 LOC100128838 Nonsynonymous       G 0.003587
#C1S688          1  1105324       TTLL10 Nonsynonymous       T 0.014347
#C1S689          1  1105366       TTLL10 Nonsynonymous       C 0.005022
#C1S690          1  1105373       TTLL10 Nonsynonymous       T 0.001435

##### find nonsynonymous usnp (i.e. at least one snp must be nonsyn)
usnp.SYN = list(length=15076)
for (i in 1:15076)
{
  usnp.SYN[[i]] <- snpInfo[usnp2snp[[i]],"snp_type"]
}
nonsyn.id = vector(length=15076)
for (i in 1:15076)
{
  nonsyn.id[i]<- (table(usnp.SYN[[i]])[ "Nonsynonymous" ] > 0)
}

sum(nonsyn.id)  # 8020

###### examples
nonsyn.id[3986] #TRUE
usnp.SYN[[3986]] 
#[1] Nonsynonymous Nonsynonymous Unknown       Nonsynonymous Nonsynonymous
#[6] Nonsynonymous Synonymous  

nonsyn.id[150] #FALSE
usnp.SYN[[150]]#Synonymous



####### create filtered data matrix


x<-x.usnp[,nonsyn.id]
dim(x) #697 8020
dim(x.usnp) #697 15076

x.map<-usnp2snp[nonsyn.id]

snpInfo[x.map[[213]],]
#         chromosome  position   gene      snp_type variant      maf
#C1S2080           1  35975552  CLSPN Nonsynonymous       A 0.000717
#C2S3628           2 148943492   MBD5 Nonsynonymous       G 0.000717
#C3S3639           3 122895929 GOLGB1 Nonsynonymous       G 0.000717
#C7S4818           7 148534820 ZNF282 Nonsynonymous       C 0.000717
#C12S1803         12  38937338  LRRK2 Nonsynonymous       C 0.001435
#C12S2862         12  52105585  AMHR2    Synonymous       C 0.000717
#C13S1151         13  38330017  FREM2    Synonymous       A 0.000717
#C16S4366         16  88125857   SPG7    Synonymous       T 0.000717
#C17S2256         17  32385227   AATF Nonsynonymous       T 0.000717


######### create response vectors

y1 = matrix(nrow=697,ncol=200)
for ( i in 1:200)
{
  Q1 = as.matrix( pheno[[i]]["Q1"] )
  SEX = as.matrix(  pheno[[i]]["SEX"])
  AGE = as.matrix(  pheno[[i]]["AGE"])
  SMOKE = as.matrix(  pheno[[i]]["SMOKE"])
  lm.out = lm(Q1 ~ SEX+AGE+SMOKE)
  y1[,i] = scale(lm.out$residuals)
}

y2 = matrix(nrow=697,ncol=200)
for ( i in 1:200)
{
  Q2 = as.matrix( pheno[[i]]["Q2"])
  SEX =  as.matrix( pheno[[i]]["SEX"])
  AGE =  as.matrix( pheno[[i]]["AGE"])
  SMOKE =  as.matrix( pheno[[i]]["SMOKE"])
  lm.out = lm(Q2 ~ SEX+AGE+SMOKE)
  y2[,i] = scale(lm.out$residuals)
}


####### create filtered version of the true positive list

x.SNP = list(length=8020)
for (i in 1:8020)
{
  x.SNP[[i]] <- rownames(snpInfo)[x.map[[i]]]
}



# Q1

dim(trueQ1)
#39 4

id.Q1 <- vector(length=39)
for(j in 1:39){
  for(i in 1:8020){
    if(trueQ1[j,"SNP"]%in%x.SNP[[i]]==TRUE)
    id.Q1[j]=i
  }
}

# id.TPQ2 is of length 8020 == TRUE if snp (profile)
# is listed in the true positiv list

id.TPQ1<-vector(length=8020, mode="logical")
for(i in 1:39){
  id.TPQ1[id.Q1[i]]<-TRUE
}

summary(id.TPQ1)
#   Mode   FALSE    TRUE    NA's 
#logical    7982      38       0 

# Q2

dim(trueQ2)
#72 4
id.Q2 <- vector(length=72)

for(j in 1:72){
  for(i in 1:8020){
    if(trueQ2[j,"SNP"]%in%x.SNP[[i]]==TRUE)
    id.Q2[j]=i
  }
}

# id.TPQ2 is of length 8020 == TRUE if snp (profile) 
#is listed in the true positiv list

id.TPQ2<-vector(length=8020, mode="logical")
for(i in 1:72){
  id.TPQ2[id.Q2[i]]<-TRUE
}

summary(id.TPQ2)
#   Mode   FALSE    TRUE    NA's 
#logical    7949      71       0 


########################################################################
########################################################################



save(x, x.map, y1, y2,
     snpInfo, trueQ1, id.TPQ1, trueQ2, id.TPQ2, 
     file="rda/workingdata.rda")



