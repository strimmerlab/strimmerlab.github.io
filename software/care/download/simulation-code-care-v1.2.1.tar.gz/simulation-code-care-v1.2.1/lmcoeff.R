
# original version 1 June 2010
# 24 July 2011 updated for "care" package version 1.1.1
# 30 March 2014 updated 
# 23 November 2014 update for "care" package version 1.1.7


require("scout") # for elastic net and lasso
require("care")  # for car scores

###########################################################
# this function provides a unified interface to learn a linear model
# (i.e. compute  regression coefficients)
# available methods: OLS, CAR, lasso, enet
###########################################################

# Xtrain:    observations predictors
# Xtrain:    observations response
# lambda:    regularization parameter(s)
# method:    one of ols, car, lasso, enet
# estimator:  empirical or shrinkage estimator (for CAR score)

# returns p+1 vector of regression coefficients (incl. intercept)


lmcoeff = function(Xtrain, Ytrain, 
              lambda,
              method=c("ols", "car", "lasso", "enet"), 
              estimator=c("empirical", "shrinkage"))
{
  method = match.arg(method)
  estimator = match.arg(estimator)

  if (method == "ols")
  {
    coeff = lm(Ytrain ~ Xtrain)$coefficients
  }

  if (method == "enet") # lambda=c(lambda1,lambda2)
  {
    s.out = scout(x=Xtrain, y=Ytrain, p1=2, p2=1, 
      trace=FALSE, lam1s=lambda[1], lam2s=lambda[2], standardize=TRUE)
    coeff = c( s.out$intercepts[1,1], s.out$coefficients[1,1,] )
  }
 
  if (method == "lasso") # lambda=c(lambda2)
  {
    s.out = scout(x=Xtrain, y=Ytrain, p1=NULL, p2=1, 
       trace=FALSE, lam1s=0, lam2s=lambda, standardize=TRUE)
    coeff = c( s.out$intercepts[1,1], s.out$coefficients[1,1,] )
  }

  if (method == "car") # lambda=c(k)
  {
    if (estimator=="shrinkage")
    {
      car = carscore(Xtrain, Ytrain, verbose=FALSE)
      ocar = order(car^2, decreasing=TRUE)
      car.predlist = make.predlist(ocar, numpred = lambda, name="CAR")
      coeff = slm(Xtrain, Ytrain, predlist=car.predlist, verbose=FALSE)$coefficients[1,]
    }
    else
    {
      car = carscore(Xtrain, Ytrain, lambda=0, verbose=FALSE)
      ocar = order(car^2, decreasing=TRUE)
      car.predlist = make.predlist(ocar, numpred = lambda, name="CAR")
      coeff = slm(Xtrain, Ytrain, predlist=car.predlist, lambda=0, lambda.var=0, 
             verbose=FALSE)$coefficients[1,]
    }
  }

  xnames = colnames(Xtrain)
  if (is.null(xnames) ) 
    xnames = paste("X", 1:dim(Xtrain)[2], sep="")
  names(coeff) = c("(Intercept)", xnames)

  return( coeff )
}



########################################################################
# predict from linear model

# coeff: (p+1) vector of regression coefficients
# Xtest:  n x p matrix
# coeff:  (p+1) vector
   
# returns response

lmpredict = function(coeff, Xtest)
{
  b = matrix(coeff[-1])  # p x 1 matrix
  b0 = coeff[1]

  return( b0 + Xtest %*% b )
}




