
# 1 june 2010

# simulation script for Zuber and Strimmer (2010)

# requires the following R packages from CRAN:
# scout, glasso, lars, care, corpcor


source("sim.data.R")        # functions for simulating data 
source("lmcoeff.R")         # unified interface for computing regression coefficients 
                            # for OLS, lasso, enet, CAR
                            # (with specified regularization parameter)

source("optimal.val.R")     # functions for optimizing regularizing parameter
                            # using validation data set

source("run-simulation.R")  # run the simulation


### specify regression model #################################################################

# this is model from from example 1

beta = c(3, 1.5, 0, 0, 2, 0, 0, 0)
p = length(beta)

R = diag(p)
for (i in 1:p)
{
  for (j in 1:p)
  {
    R[i, j] = 0.5^(abs(i-j))
  }
}
cR = chol(R)

varX = rep(1, p)

Sigma = diag(sqrt(varX)) %*% R  %*% diag(sqrt(varX))

#########################################################################

# n=50 and sdEps=3 (varEps=9) 

## empirical CAR 

results.car = run.simulation("car", n=50, varEps=9, store.coeff=TRUE)
report.arme(results.car$moderr, varEps=9) # 119   7
median(results.car$model.size) # 3

## OLS 

results.ols = run.simulation("ols", n=50, varEps=9, store.coeff=TRUE)
report.arme(results.ols$moderr, varEps=9) # 230 9
median(results.ols$model.size) # 8

## lasso 

results.lasso = run.simulation("lasso", n=50, varEps=9, store.coeff=TRUE)
report.arme(results.lasso$moderr, varEps=9) # 148 6
median(results.lasso$model.size) # 5

## enet (this takes a while!)

results.enet = run.simulation("enet", n=50, varEps=9, store.coeff=TRUE)
report.arme(results.enet$moderr, varEps=9) # 130 6
median(results.enet$model.size) # 5


#########################################################################

# box plots of regression coefficients in one plot (Figure 1 of Zuber and Strimmer 2010)

betanames=expression(a[],b[1],b[2],b[3],
      b[4],b[5],b[6],b[7],b[8])

par(mfrow=c(2,2))
betaboxplot(results.car$coeffmat, main="Empirical CAR", ylim=c(-2, 5.5), names=betanames )
betaboxplot(results.enet$coeffmat, main="Elastic Net", ylim=c(-2, 5.5), names=betanames )
betaboxplot(results.lasso$coeffmat, main="Lasso", ylim=c(-2, 5.5), names=betanames )
betaboxplot(results.ols$coeffmat, main="OLS", ylim=c(-2, 5.5), names=betanames )
par(mfrow=c(1,1))


