
# 20 Jan 2010
# 30 March 2014 adapted to use crossval

# find optimal regularization parameters using validation data set



# estimation of prediction error
# using a test data set
lmprederr.test = function(Xtrain, Ytrain, Xtest, Ytest, ...)
{
  coeff = lmcoeff(Xtrain, Ytrain, ...)
  ynew = lmpredict(coeff, Xtest)

  err.vec = as.vector( (Ytest-ynew)^2 )
  err = c( mean ( err.vec ), 
             sd(err.vec)/sqrt(length(err.vec)) )
  names(err) = c("PE", "PE.SE")

  return( list(err.vec=err.vec, err=err))
}


# find optimal parameter for a given test and training data

bestlambda.test = function(Xtrain, Ytrain, Xval, Yval, lambdas, ...)
{
  lambdas = as.matrix(lambdas)
  perr.val = numeric(dim(lambdas)[1])

  for (i in 1:length(perr.val))
  { 
    #cat("Computing prediction error #", i, "of", length(perr.val), "\n")
    perr.val[i] = lmprederr.test(Xtrain, Ytrain, Xval, Yval, lambda=lambdas[i,], ...)$err[1]
  }
  min.idx = which.min(perr.val)[1]

  return( lambdas[min.idx,] )
}


########################################################################


# return regression coefficients for optimal lasso
optimallasso = function(Xtrain, Ytrain, Xval, Yval,
                  lambdas=seq(0.001, 0.2,len=10))
{
  # find optimal LASSO predictor
     
  ll = bestlambda.test(Xtrain, Ytrain, Xval, Yval, lambdas=lambdas, method="lasso")
  
  coeff = lmcoeff(Xtrain, Ytrain, method="lasso", lambda=ll)

  return( coeff )
}


# return regression coefficients for optimal car model
optimalcar = function(Xtrain, Ytrain, Xval, Yval,
              lambdas=1:dim(Xtrain)[2],
             estimator="empirical")
{
  ## find optimal CAR predictor

  ll = bestlambda.test(Xtrain, Ytrain, Xval, Yval, lambdas=lambdas, method="car", estimator=estimator)
  
  coeff = lmcoeff(Xtrain, Ytrain, method="car", lambda=ll, estimator=estimator)

  return( coeff )
}


# return regression coefficients for optimal enet
optimalenet = function(Xtrain, Ytrain, Xval, Yval, 
   lam1s=seq(0.001, 0.2,len=10), lam2s=seq(0.001, 0.2,len=10))
{
  # find optimal ENET predictor

  l1 = length(lam1s)
  l2 = length(lam2s)
  lambdas = cbind( rep(lam1s, rep(l2, l1)), rep(lam2s, l1) )

  ll = bestlambda.test(Xtrain, Ytrain, Xval, Yval, lambdas=lambdas, method="enet")
  
  coeff = lmcoeff(Xtrain, Ytrain, method="enet", lambda=ll)

  return( coeff )
}

