
The R scripts in this directory allow to reproduce the simulations
of Zuber and Strimmer (2011). 

Please install the following packages from CRAN:

 care
 corpcor
 crossval

as well as

 scout
 glasso
 lars

Then open the file "main-sim.R" and run the R code.

For computing cross-validation estimates run the R script 
in the file "main-cv.R".


