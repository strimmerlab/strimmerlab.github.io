# 30 March 2014

# example for crossvalidation

## install these packages first

#install.packages(c("scout", "care", "crossval"))
 # installs: scout, glasso, lars, care, corpcor, crossval

################
 
library("care")
library("crossval")

source("lmcoeff.R")      # contains lmcoeff() and lmpredict()
source("optimal.cv.R")   # optimize lambda using CV


######

data(lu2004)

Y = scale(lu2004$y)
X1 = scale(lu2004$x)


######

## lasso

lam2s=seq(0.001, 0.2, len=10)

# find best lambda
bestlam = bestlambda.cv(X1, Y, K=5, B=5, lambdas=lam2s, method="lasso")
bestlam
# 0.001

# compute regression coefficients 
lasso.coeff = lmcoeff(X1, Y, method="lasso", lambda=bestlam )
sum(lasso.coeff[-1] != 0)  # minus 1 because coeff includes intercept
# 36 variables

# estimate prediction error for best lambda
lasso.prederr36 =  lmprederr.cv(X1, Y, K=5, B=100, method="lasso", lambda=0.001)
lasso.prederr36
# 0.40061111
# 0.01158599 


## estimate predictor error for corresponding CAR model (with 36 variables)
car.prederr36 = lmprederr.cv(X1, Y, K=5,B=100, method="car", lambda=36, estimator="shrinkage" )
car.prederr36
#0.335664935
#0.007071386



