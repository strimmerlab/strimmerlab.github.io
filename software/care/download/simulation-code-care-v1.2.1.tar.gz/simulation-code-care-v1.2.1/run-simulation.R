
# 21 Januar 2010

# added tp/fp instead of model size

### main function for running the simulation 

# methods:  car  employs empirical CAR
#           car2 employs shrinkage CAR


# method:  type of regression approach
# B:       number of repeats
# n:       sample size for training and validation data sets
# varEps:  variance of error term
# store.coeff:   store estimated all regression coefficients in each round

run.simulation = function(
  method=c("car", "car2", "ols", "lasso", "enet"),
  B = 200, n=50, varEps=9, store.coeff=FALSE)
{ 
  method = match.arg(method)

  n1=n # size of training data
  n2=n # size of validation data

  moderr = numeric(B)
  model.size = numeric(B)
  model.tp = numeric(B) 

  p = length(beta)
  true.variables = (beta != 0) 
 
  if (store.coeff)
     coeffmat = matrix(0, ncol=p+1, nrow=B)
  else
     coeffmat = NULL

  for (iii in 1:B)
  {
    print(iii)
  
    #### generate training and validation data sets 
    train = sim.lm.data(n1, beta, cR = cR, sdX = sqrt(varX), sdEps = sqrt(varEps))
    val = sim.lm.data(n2, beta, cR = cR, sdX = sqrt(varX), sdEps = sqrt(varEps))
    
    #### fit coefficients using training data and   
    #### choose optimal cutoff using validation data 
 
    if (method == "car") coeff = optimalcar(train$X, train$Y, val$X, val$Y, estimator="empirical")
    if (method == "car2") coeff = optimalcar(train$X, train$Y, val$X, val$Y, estimator="shrinkage")
    if (method == "lasso") coeff = optimallasso(train$X, train$Y, val$X, val$Y)
    if (method == "enet") coeff = optimalenet(train$X, train$Y, val$X, val$Y)
    if (method == "ols") coeff = lmcoeff(train$X, train$Y, method="ols")

    if( !is.null(coeffmat) ) coeffmat[iii,] = coeff # store coefficients


    #### determine size of estimated model
    model.size[iii] = sum(coeff[-1] !=0) # don't count intercept 
    model.tp[iii]   = sum(coeff[c(FALSE, true.variables)] !=0)

    #### estimate model error
 
    intercept.delta = coeff[1]-0
    beta.delta = coeff[-1] - beta
    moderr[iii] = t(beta.delta) %*% Sigma %*% beta.delta + intercept.delta^2
    
    # relationship of model error with prediction error
    # model error:          me
    # prediction error:     me + varEps
    # relative model error: me/varEps

    # we could also estimate predictor error by simulation of a test data set
    # prediction error
    # prederr[iii] = moderr[iii] + varEps
    #n3=400 #  size of test data
    #test = sim.lm.data(n3, beta, cR = cR, sdX = sqrt(varX), sdEps = sqrt(varEps))
    #prederr[iii] = mean( (test$Y - lmpredict(coeff, test$X) )^2 )

  }

  return( list(coeffmat=coeffmat, moderr=moderr, 
     model.size=model.size, model.tp=model.tp)  )
}


########################################################################
# some other useful functions


# 1000 x average relative model error and its error (for table)
report.arme = function(me, varEps)
{
  arme = mean(me/varEps)
  arme.se = sd(me/varEps)/sqrt(length(me))

  return( round( c(arme, arme.se)*1000 ) )
}


collectresults = function(method="ols")
{
  out = matrix(0, 9, 6)
  colnames(out) = c("ARME", "ARME.SE", "med.size", "med.model.tp", "med.model.fp", "med.model.fp.2")
  rownames(out) = c("n20-s1", "n20-s3", "n20-s6", 
                     "n50-s1", "n50-s3", "n50-s6",
                     "n100-s1", "n100-s3", "n100-s6")

  
  results = run.simulation(method, n=20, varEps=1)
  out[1,1:2] = report.arme(results$moderr, varEps=1)
  out[1,3] = median(results$model.size)
  out[1,4] = median(results$model.tp)
  out[1,5] = median(results$model.size-results$model.tp)
  out[1,6] = out[1,3]-out[1,4]

  results = run.simulation(method, n=20, varEps=9)
  out[2,1:2] = report.arme(results$moderr, varEps=9) 
  out[2,3] = median(results$model.size)
  out[2,4] = median(results$model.tp)
  out[2,5] = median(results$model.size-results$model.tp)
  out[2,6] = out[2,3]-out[2,4]

  results = run.simulation(method, n=20, varEps=36)
  out[3,1:2] = report.arme(results$moderr, varEps=36) 
  out[3,3] = median(results$model.size)
  out[3,4] = median(results$model.tp)
  out[3,5] = median(results$model.size-results$model.tp)
  out[3,6] = out[3,3]-out[3,4]

  results = run.simulation(method, n=50, varEps=1)
  out[4,1:2] = report.arme(results$moderr, varEps=1)
  out[4,3] = median(results$model.size)
  out[4,4] = median(results$model.tp)
  out[4,5] = median(results$model.size-results$model.tp)
  out[4,6] = out[4,3]-out[4,4]

  results = run.simulation(method, n=50, varEps=9)
  out[5,1:2] = report.arme(results$moderr, varEps=9) 
  out[5,3] = median(results$model.size)
  out[5,4] = median(results$model.tp)
  out[5,5] = median(results$model.size-results$model.tp)
  out[5,6] = out[5,3]-out[5,4]

  results = run.simulation(method, n=50, varEps=36)
  out[6,1:2] = report.arme(results$moderr, varEps=36) 
  out[6,3] = median(results$model.size)
  out[6,4] = median(results$model.tp)
  out[6,5] = median(results$model.size-results$model.tp)
  out[6,6] = out[6,3]-out[6,4]

  results = run.simulation(method, n=100, varEps=1)
  out[7,1:2] = report.arme(results$moderr, varEps=1) 
  out[7,3] = median(results$model.size)
  out[7,4] = median(results$model.tp)
  out[7,5] = median(results$model.size-results$model.tp)
  out[7,6] = out[7,3]-out[7,4]

  results = run.simulation(method, n=100, varEps=9)
  out[8,1:2] = report.arme(results$moderr, varEps=9) 
  out[8,3] = median(results$model.size)
  out[8,4] = median(results$model.tp)
  out[8,5] = median(results$model.size-results$model.tp)
  out[8,6] = out[8,3]-out[8,4]

  results = run.simulation(method, n=100, varEps=36)
  out[9,1:2] = report.arme(results$moderr, varEps=36)  
  out[9,3] = median(results$model.size)
  out[9,4] = median(results$model.tp)
  out[9,5] = median(results$model.size-results$model.tp)
  out[9,6] = out[9,3]-out[9,4]

  return(out)
}


betaboxplot = function(coeffmat, ...)
{
  p = dim(coeffmat)[2]-1

  betalist = vector("list", p+1)
  names(betalist)=paste("beta", 0:p, sep="")
  for (i in 1:(p+1))
    betalist[[i]] = coeffmat[,i]

  boxplot(betalist, ylab="Estimated Value", ...)
} 


