#
# 7 September 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#


# Read data
load(file="rda/workingdata.rda")
load("rda/Q1.hits.rda")
load("rda/Q2.hits.rda")

library(corpcor) # for sm2vec


########################################################################
# Q1


idQ1 = which(id.TPQ1==TRUE)			#which SNPs are TP (in 1:8020)


table.id=matrix(nrow=38, ncol=2)		#matrix to match trueQ1 with idQ1
snp.name=matrix(nrow=38, ncol=2)                #matrix to recover the SNP name (in order of x)
for(i in 1:38){
table.id[i,]=which(trueQ1[,2]%in%rownames(snpInfo[unlist(x.map[idQ1] [i]),]) == TRUE)
snp.name[i,]=as.character(trueQ1[table.id[i,],2])
}

# there are two identical SNPs in trueQ1!

i=9
which(trueQ1[,2]%in%rownames(snpInfo[unlist(x.map[idQ1] [i]),]) == TRUE)
# TP SNP 31 and 36 in trueQ1 have the same genetic profile



# sort trueQ1 according to idQ1 (the order of the SNP data x)
# sort.trueQ1 has the same ordering of TP SNPs as in the SNP data x

sort.trueQ1 = trueQ1[table.id[,1],]
resultsQ1=cbind(sort.trueQ1,t(Q1.hits))
resultsQ1
#     GENE      SNP      MAF    BETA CAR COR NEG MCP BOOST LASSO RND
#2    ARNT  C1S6537 0.000717 0.64454  10   0  13   6     6     8   1
#21  HIF1A C14S1718 0.000717 0.15382   2   0   7   2     1     1   0
#35    KDR  C4S1887 0.000717 0.29558  14   2   5   1     2     2   1
# ...



# sort TP according to genes

sortTPQ1.gene=sort.int(as.character(sort.trueQ1[,1]), index.return=TRUE)
sortTPQ1.gene$x
# [1] "ARNT"   "ARNT"   "ARNT"   "ARNT"   "ARNT"   "ELAVL4" "ELAVL4" "FLT1"  
# [9] "FLT1"   "FLT1"   "FLT1"   "FLT1"   "FLT1"   "FLT1"   "FLT1"   "FLT1"  
#[17] "FLT1"   "FLT1"   "FLT4"   "FLT4"   "HIF1A"  "HIF1A"  "HIF1A"  "HIF1A" 
#[25] "HIF3A"  "HIF3A"  "HIF3A"  "KDR"    "KDR"    "KDR"    "KDR"    "KDR"   
#[33] "KDR"    "KDR"    "KDR"    "KDR"    "VEGFA"  "VEGFC" 



# correlation matrix of the 38 TP SNPs ordered by gene name

corQ1=cor(x[,idQ1[sortTPQ1.gene$ix]])			
dim(corQ1)
#[1] 38 38

colnames(corQ1)=snp.name[sortTPQ1.gene$ix,1]
rownames(corQ1)=snp.name[sortTPQ1.gene$ix,1]


mean( abs(sm2vec(corQ1) ) ) # 0.01438839
range(sm2vec(corQ1) ) # -0.1163007  0.7065986

# Hits sorted by gene
sort.hitsQ1=resultsQ1[sortTPQ1.gene$ix,]
rownames(sort.hitsQ1)=1:38
sort.hitsQ1

###

# correlation matrix for
# FLT1   C13S431  
# FLT1   C13S522  
# FLT1   C13S523  
# FLT1   C13S524   

FLT1=c("C13S431","C13S522","C13S523","C13S524")

corQ1[FLT1, FLT1]
#            [,1]       [,2]       [,3]        [,4]
#[1,]  1.00000000 0.05673141 0.04159853 -0.01759684
#[2,]  0.05673141 1.00000000 0.36342178  0.24760590
#[3,]  0.04159853 0.36342178 1.00000000  0.19179979
#[4,] -0.01759684 0.24760590 0.19179979  1.00000000

mean(sm2vec(corQ1[15:18, 15:18]))  # 0.1472601


# correlation matrix for
# KDR    C4S1877  
# KDR    C4S1878  
# KDR    C4S1884  

KDR=c("C4S1877","C4S1878","C4S1884")

corQ1[KDR, KDR]
#             C4S1877   C4S1878      C4S1884
#C4S1877  1.000000000 0.1181421 -0.007384286
#C4S1878  0.118142144 1.0000000  0.205993230
#C4S1884 -0.007384286 0.2059932  1.000000000

mean(sm2vec(abs( corQ1[KDR,KDR]))) # 0.1105066


########################################################################
# Q2


idQ2 = which(id.TPQ2==TRUE)			#which SNPs are TP (in 1:8020)


table.id=matrix(nrow=71, ncol=2)		#matrix to match trueQ2 with idQ2
snp.name=matrix(nrow=71, ncol=2)                #matrix to recover the SNP name
for(i in 1:71){
table.id[i,]=which(trueQ2[,2]%in%rownames(snpInfo[unlist(x.map[idQ2] [i]),]) == TRUE)
snp.name[i,]=as.character(trueQ2[table.id[i,],2])
}




# there are two identical SNPs in trueQ2!

i=23
which(trueQ2[,2]%in%rownames(snpInfo[unlist(x.map[idQ2] [i]),]) == TRUE)
# TP SNP 31 and 36 in trueQ2 have the same genetic profile



# sort trueQ2 according to idQ2

sort.trueQ2 = trueQ2[table.id[,1],]
resultsQ2=cbind(sort.trueQ2,t(Q2.hits))
resultsQ2
#     GENE      SNP      MAF    BETA CAR COR NEG MCP BOOST LASSO RND
#26   PLAT  C8S1742 0.000717 0.84910   4   4   1   1     3     1   1
#45 SREBF1 C17S1009 0.000717 0.64568   0   1   1   1     4     0   4
#57  VLDLR   C9S391 0.000717 0.52694   0   1   1   1     2     2   3

# ...


sortTPQ2.gene=sort.int(as.character(sort.trueQ2[,1]), index.return=TRUE)
sortTPQ2.gene$x
# [1] "BCHE"   "BCHE"   "BCHE"   "BCHE"   "BCHE"   "BCHE"   "BCHE"   "BCHE"  
# [9] "BCHE"   "BCHE"   "BCHE"   "BCHE"   "BCHE"   "GCKR"   "INSIG1" "INSIG1"
#[17] "INSIG1" "LPL"    "LPL"    "LPL"    "PDGFD"  "PDGFD"  "PDGFD"  "PDGFD" 
#[25] "PLAT"   "PLAT"   "PLAT"   "PLAT"   "PLAT"   "PLAT"   "PLAT"   "PLAT"  
#[33] "RARB"   "RARB"   "SIRT1"  "SIRT1"  "SIRT1"  "SIRT1"  "SIRT1"  "SIRT1" 
#[41] "SIRT1"  "SIRT1"  "SREBF1" "SREBF1" "SREBF1" "SREBF1" "SREBF1" "SREBF1"
#[49] "SREBF1" "SREBF1" "SREBF1" "SREBF1" "VLDLR"  "VLDLR"  "VLDLR"  "VLDLR" 
#[57] "VLDLR"  "VLDLR"  "VLDLR"  "VLDLR"  "VNN1"   "VNN1"   "VNN3"   "VNN3"  
#[65] "VNN3"   "VNN3"   "VNN3"   "VNN3"   "VNN3"   "VWF"    "VWF"


# correlation matrix of the 38 TP SNPs ordered by gene name

corQ2=cor(x[,idQ2[sortTPQ2.gene$ix]])			
dim(corQ2)
#71 71

colnames(corQ2)=snp.name[sortTPQ2.gene$ix,1]
rownames(corQ2)=snp.name[sortTPQ2.gene$ix,1]


mean( abs(sm2vec(corQ2) ) ) # 0.007515673
range(sm2vec(corQ2) ) # -0.1045083  0.5765201



# Hits sorted by gene
sort.hitsQ2=resultsQ2[sortTPQ2.gene$ix,]
rownames(sort.hitsQ2)=1:71


###
# correlation for
# SIRT1 | C10S3050  
# SIRT1 | C10S3048  
  
corQ2["C10S3050","C10S3048"]		#  0.3304515

#VNN3 | C6S5441    
#VNN3 | C6S5449    


corQ2["C6S5441","C6S5449"]		# -0.06616815

#BCHE | C3S4875    
#BCHE | C3S4869    

corQ2["C3S4875","C3S4869"]		# -0.001436782

