#
# 7 September 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#


# model sizes for the investigated snp selection strategies

# for CAR and COR see separate file

#######################################
# Q1

# Read data
load(file="rda/BOOST.Q1.rda")
load(file="rda/LASSO.Q1.rda")
load(file="rda/NEG.Q1.rda")
load(file="rda/MCP.Q1.rda")

## NEG
ms.NEG.Q1 = rowSums( ifelse(NEG.Q1 ==0, 0, 1) )
range( ms.NEG.Q1 )    # 1201 1617
median( ms.NEG.Q1 )   # 1390
IQR( ms.NEG.Q1 )      # 117.75

## MCP
ms.MCP.Q1 = rowSums( ifelse(MCP.Q1 ==0, 0, 1) )
range( ms.MCP.Q1 )    # 12 32
median( ms.MCP.Q1 )   # 20
IQR( ms.MCP.Q1 )      # 5

## boosting
ms.BOOST.Q1 = rowSums( ifelse(BOOST.Q1 ==0, 0, 1) )
range( ms.BOOST.Q1 )    # 39 64
median( ms.BOOST.Q1 )   # 53
IQR( ms.BOOST.Q1 )      # 5

## lasso
ms.LASSO.Q1 = rowSums( ifelse(LASSO.Q1 ==0, 0, 1) )
range( ms.LASSO.Q1 )    # 5 273
median( ms.LASSO.Q1 )   # 37
IQR( ms.LASSO.Q1 )      # 31


#######################################
# Q2

# Read data
load(file="rda/BOOST.Q2.rda")
load(file="rda/LASSO.Q2.rda")
load(file="rda/NEG.Q2.rda")
load(file="rda/MCP.Q2.rda")

## NEG
ms.NEG.Q2 = rowSums( ifelse(NEG.Q2 ==0, 0, 1) )
range( ms.NEG.Q2 )    # 16 3829
median( ms.NEG.Q2 )   # 1632
IQR( ms.NEG.Q2 )      # 754.75

## MCP
ms.MCP.Q2 = rowSums( ifelse(MCP.Q2 ==0, 0, 1) )
range( ms.MCP.Q2 )    # 20 40
median( ms.MCP.Q2 )   # 29
IQR( ms.MCP.Q2 )      # 5

## boosting
ms.BOOST.Q2 = rowSums( ifelse(BOOST.Q2 ==0, 0, 1) )
range( ms.BOOST.Q2 )    # 46 68
median( ms.BOOST.Q2 )   # 59
IQR( ms.BOOST.Q2 )      # 6

## lasso
ms.LASSO.Q2 = rowSums( ifelse(LASSO.Q2 ==0, 0, 1) )
range( ms.LASSO.Q2 )    # 0 245
median( ms.LASSO.Q2 )   # 15
IQR( ms.LASSO.Q2 )      # 35.5


#######################################
# Q4

# Read data
load(file="rda/BOOST.Q4.rda")
load(file="rda/LASSO.Q4.rda")
load(file="rda/NEG.Q4.rda")
load(file="rda/MCP.Q4.rda")

## NEG
ms.NEG.Q4 = rowSums( ifelse(NEG.Q4 ==0, 0, 1) )
range( ms.NEG.Q4 )    #  2 4114
median( ms.NEG.Q4 )   # 1899.5
IQR( ms.NEG.Q4 )      # 2713.25

## MCP
ms.MCP.Q4 = rowSums( ifelse(MCP.Q4 ==0, 0, 1) )
range( ms.MCP.Q4 )    # 17 37
median( ms.MCP.Q4 )   # 27
IQR( ms.MCP.Q4 )      # 4

## boosting
ms.BOOST.Q4 = rowSums( ifelse(BOOST.Q4 ==0, 0, 1) )
range( ms.BOOST.Q4 )    # 49 70
median( ms.BOOST.Q4 )   # 59
IQR( ms.BOOST.Q4 )      # 6

## lasso
ms.LASSO.Q4 = rowSums( ifelse(LASSO.Q4 ==0, 0, 1) )
range( ms.LASSO.Q4 )    # 0 78
median( ms.LASSO.Q4 )   # 1
IQR( ms.LASSO.Q4 )      # 6

