#
# 7 September 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#



# model sizes for the investigated SNP selection strategies

# for CAR and COR 

# read functions
library("fdrtool")


getThresh = function(score.mat)
{
  LFDR05 = numeric(200)

  for (i in 1:200)
  {
    cat("round", i, "\n")
    z = score.mat[i,]
    fdr.out = fdrtool(z, statistic="correlation", plot=FALSE, verbose=FALSE)

    LFDR05[i] = sum(fdr.out$lfdr < 0.5)
   }
   return( list(LFDR05=LFDR05) )
}




###########################
# Q1

# Read data
load(file="rda/COR.Q1.rda")
load(file="rda/CAR.Q1.rda")


# CAR score
th = getThresh(CAR.Q1)

# local FDR < 0.5
range( th$LFDR05 )    # 2 271
median( th$LFDR05 )   # 50.5
IQR( th$LFDR05 )      # 53.25


# marginal correlation
th = getThresh(COR.Q1)

# local FDR < 0.5
range( th$LFDR05 )    # 28 455
median( th$LFDR05 )   # 176
IQR( th$LFDR05 )      # 108.25



###########################
# Q2

# Read data
load(file="rda/COR.Q2.rda")
load(file="rda/CAR.Q2.rda")


# CAR score
th = getThresh(CAR.Q2)

# local FDR < 0.5
range( th$LFDR05 )    # 0 217
median( th$LFDR05 )   # 31
IQR( th$LFDR05 )      # 38


# marginal correlation
th = getThresh(COR.Q2)

# local FDR < 0.5
range( th$LFDR05 )    # 0 133
median( th$LFDR05 )   # 1
IQR( th$LFDR05 )      # 7

###########################
# Q4

# Read data
load(file="rda/COR.Q4.rda")
load(file="rda/CAR.Q4.rda")


# CAR score
th = getThresh(CAR.Q4)

# local FDR < 0.5
range( th$LFDR05 )    # 0 176
median( th$LFDR05 )   # 33.5
IQR( th$LFDR05 )      # 39.25


# marginal correlation
th = getThresh(COR.Q4)

# local FDR < 0.5
range( th$LFDR05 )    # 0 79
median( th$LFDR05 )   # 0
IQR( th$LFDR05 )      # 1


