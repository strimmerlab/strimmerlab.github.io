#
# 7 September 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#

# if we make cutoff at some threshold, which true SNP has been picked how often?


# Read data
load(file="rda/workingdata.rda")

####
# number the true SNPs

sum(id.TPQ1) # 38
number.TPQ1 = numeric(8020)
number.TPQ1[which(id.TPQ1)] = 1:38

sum(id.TPQ2) # 71
number.TPQ2 = numeric(8020)
number.TPQ2[which(id.TPQ2)] = 1:71

####


getHits = function(stat, ntp, thresh)
{
  if (length(ntp) != length(stat)) stop("arguments must have same length")
  
  # randomize order (to avoid using input order for vanishing coefficients) 
  shuffle = sample(length(ntp)) 
  stat = stat[shuffle]
  ntp = ntp[shuffle]

  # sort statistics in decreasing magnitude
  ostat = order(abs(stat), decreasing=TRUE)

  hits = ntp[ostat[1:thresh]]
  hits = hits[hits > 0]

  return(hits)
}


collectHits = function(stat.mat, ntp, thresh)
{
  B = dim(stat.mat)[1]

  counts = numeric(max(ntp))

  for (i in 1:B)
  {
     h = getHits(stat.mat[i,], ntp, thresh)
     counts[ h ] = counts[h] +1
  }

  return(counts)
}

##############
# results


thresh = 100


#### Q1

load(file="rda/CAR.Q1.rda")
load(file="rda/COR.Q1.rda")
load(file="rda/NEG.Q1.rda")
load(file="rda/MCP.Q1.rda")
load(file="rda/BOOST.Q1.rda")
load(file="rda/LASSO.Q1.rda")
load(file="rda/RND.Q1.rda")

Q1.hits = matrix(ncol=38, nrow=7)
rownames(Q1.hits) = c("CAR", "COR", "NEG", "MCP", "BOOST", "LASSO", "RND")
colnames(Q1.hits)=paste("S",1:38, sep="")

Q1.hits[1,] = collectHits(CAR.Q1, number.TPQ1, thresh)
Q1.hits[2,] = collectHits(COR.Q1, number.TPQ1, thresh)
Q1.hits[3,] = collectHits(NEG.Q1, number.TPQ1, thresh)
Q1.hits[4,] = collectHits(MCP.Q1, number.TPQ1, thresh)
Q1.hits[5,] = collectHits(BOOST.Q1, number.TPQ1, thresh)
Q1.hits[6,] = collectHits(LASSO.Q1, number.TPQ1, thresh)
Q1.hits[7,] = collectHits(RND.Q1, number.TPQ1, thresh)

save(Q1.hits, file="rda/Q1.hits.rda")


#### Q2

load(file="rda/CAR.Q2.rda")
load(file="rda/COR.Q2.rda")
load(file="rda/NEG.Q2.rda")
load(file="rda/MCP.Q2.rda")
load(file="rda/BOOST.Q2.rda")
load(file="rda/LASSO.Q2.rda")
load(file="rda/RND.Q2.rda")

Q2.hits = matrix(ncol=71, nrow=7)
rownames(Q2.hits) = c("CAR", "COR", "NEG", "MCP", "BOOST", "LASSO", "RND")
colnames(Q2.hits)=paste("S",1:71, sep="")

Q2.hits[1,] = collectHits(CAR.Q2, number.TPQ2, thresh)
Q2.hits[2,] = collectHits(COR.Q2, number.TPQ2, thresh)
Q2.hits[3,] = collectHits(NEG.Q2, number.TPQ2, thresh)
Q2.hits[4,] = collectHits(MCP.Q2, number.TPQ2, thresh)
Q2.hits[5,] = collectHits(BOOST.Q2, number.TPQ2, thresh)
Q2.hits[6,] = collectHits(LASSO.Q2, number.TPQ2, thresh)
Q2.hits[7,] = collectHits(RND.Q2, number.TPQ2, thresh)

save(Q2.hits, file="rda/Q2.hits.rda")

##############################


load("rda/Q1.hits.rda")
load("rda/Q2.hits.rda")


rowSums(Q1.hits)
#  CAR   COR   NEG   MCP BOOST LASSO   RND 
# 1483  1346  1195   905  1210  1136   101

Q1.hits
#      S1 S2 S3 S4 S5 S6 S7 S8  S9 S10 S11 S12 S13 S14 S15 S16 S17 S18 S19 S20
#CAR   10  2 14  0  1  3  2  5 145   5   1   2  12  33   0  88   1  20   6   9
#COR    0  0  2  0  0  0  0  0 161   0   0   0   0   0   1  96   0   0   0   0
#NEG   14  5  5  3  2  0 13  8  73  12   3   6  16  11   2  87   4  18  17  15
#MCP    7  0  3  2  3  1  4  2  57   1   3   2   3   2   4  61   3  11   6   2
#BOOST  7  2  2  0  4  0  8  1  81   3   2   1   1   5   2 100   2  15   3   2
#LASSO  5  2  2  0  3  0  5  0  73   1   4   2   1   3   2  90   1  10   2   4
#RND    4  5  2  0  2  4  5  4   3   3   0   2   3   2   2   3   0   3   4   6
#      S21 S22 S23 S24 S25 S26 S27 S28 S29 S30 S31 S32 S33 S34 S35 S36 S37 S38
#CAR     1  14  91   5  11  15 101  95   3   7  69   0 110 200 200 164   0  38
#COR     0   0  25   0   0   2 128 119   1   5   5   0 143 200 200 187   0  71
#NEG     2  17  33   5  22   7  47  77   4   1  64   4 136 194 200  50   3  15
#MCP     3   4  18   1   2   2  54  61   3   2  32   3 121 163 200  52   1   6
#BOOST   0   4  32   3   2   6  78  99   6   4  61   5 161 196 200  92   2  18
#LASSO   1   7  24   0   1   4  77  92   4   4  40   2 157 195 200  93   5  20
#RND     1   2   4   1   4   3   2   1   0   3   2   5   3   2   1   5   2   3

rowSums(Q2.hits)
#  CAR   COR   NEG   MCP BOOST LASSO   RND 
# 1159  1021   860   685   875   564   185

Q2.hits
#      S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12 S13 S14 S15 S16 S17 S18 S19 S20
#CAR    4  0  0  0  1  5  5  9  1   7  24   2   0   1   0   0   2  59  41   9
#COR    4  1  1  0  2  4  3  1  0  10  11   0   0   1   0   2   3  51  10  10
#NEG    0  1  2  2  2  4  3  4  3   4  13   3   2   0   0   2   1  15  25   6
#MCP    2  2  1  1  3  2  2  4  2   2   6   2   5   2   2   1   2  15   8   4
#BOOST  2  3  0  1  1  1  2  4  0   3   9   3   1   0   0   2   1  24  12   7
#LASSO  2  0  1  2  1  3  2  1  3   3   4   1   3   1   4   1   5  13   8   4
#RND    3  0  5  5  4  4  3  0  1   5   4   2   3   4   4   3   1   4   0   0
#      S21 S22 S23 S24 S25 S26 S27 S28 S29 S30 S31 S32 S33 S34 S35 S36 S37 S38
#CAR     0  27  17  54   4  22  13   1   4   0  32   5  12   0  23   8   5  16
#COR     0   4  14  13   3   2   4   1  33   4  11   4   2   0   4   1   1   1
#NEG     1  13  11  32   2   8  11   4   9   0  16   3   5   3  13   4   7   2
#MCP     1   2   8   8   2   4   2   3  12   2   9   5   5   3   4   1   1   1
#BOOST   0   5  10  18   4   4   4   1  15   3  13   4   4   1   4   2   1   3
#LASSO   3   4   6  12   4   5   5   1  12   2   8   2   4   1   3   4   5   0
#RND     4   3   4   3   2   3   2   2   3   1   0   2   2   3   2   3   5   2
#      S39 S40 S41 S42 S43 S44 S45 S46 S47 S48 S49 S50 S51 S52 S53 S54 S55 S56
#CAR     9   8  30   1   3 138   1  59  57  69   6  49   9   0   3   1   4  40
#COR    20  31  26   2  16 160   0  66  79  77  12  16   1   0   2   1  12  19
#NEG    17   4  19   3   9 127   1  49  54  60   5  32   4   3   7   3   6  28
#MCP    10   5  13   0   4 131   2  44  59  57   5  12   1   2   4   2   6  19
#BOOST  18   8  21   1  14 136   0  59  72  78   7  21   5   4   1   1   6  24
#LASSO  13   3   7   4   6 114   5  33  46  43   1   6   3   0   0   0   3  10
#RND     7   0   4   0   3   6   2   2   3   1   2   3   4   4   1   4   2   2
#      S57 S58 S59 S60 S61 S62 S63 S64 S65 S66 S67 S68 S69 S70 S71
#CAR    11   2  54  72   4  43  15   1  20  10   5   3   4   2  13
#COR     2   8  35  86   1  63   3   8   9  26   4   3  13   1   3
#NEG     9   2  27  53  12  30   7   1  10  16   6   2   2   3  13
#MCP     4   1  20  56   3  33   3   5   5  16   6   2   6   3   5
#BOOST   3   7  29  73   1  45   4   3  11  20   5   5   6   6   9
#LASSO   4   3  11  37   3  26   5   3   4  11   2   5   4   2   4
#RND     1   3   3   3   2   4   0   2   1   1   2   2   4   2   4




