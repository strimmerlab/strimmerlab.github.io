#
# 7 September 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#



# Read data
load(file="rda/workingdata.rda")
load("rda/Q1.hits.rda")
load("rda/Q2.hits.rda")


########################################################################
# Q1

# Retrieve minor allele frequency (MAF) of the TP - SNPs


idQ1 = which(id.TPQ1==TRUE)			#which SNPs are TP (in 1:8020)


snpInfo[unlist(x.map[idQ1] [1]),]               #remap snpInfo of the first TP
#C1S1329           1  17826456    ARHGEF10L    Synonymous       C 0.000717
#C1S2255           1  37040084        GRIK3    Synonymous       T 0.000717
#...


MAF.Q1 <- numeric(length=38)
for(i in 1:38){
  MAF.Q1[i] <- snpInfo[unlist(x.map[idQ1[i]]),6] [1]   
}


# Split TP SNPs in common variants (MAF>0.01) and rare variants (MAF<0.01)

Q1.hits.c <- Q1.hits[,MAF.Q1>0.01]
dim(Q1.hits.c)
#7 7
Q1.hits.r <- Q1.hits[,MAF.Q1<0.01]
dim(Q1.hits.r)
#7 31


# Statistics of the TP selected by the 6 approaches under investigation

# Common variants
round(rowSums(Q1.hits.c)/rowSums(Q1.hits),digits=3)
#  CAR   COR   NEG   MCP BOOST LASSO   RND
#0.561 0.711 0.630 0.739 0.705 0.729 0.233 

# Rare variants
round(rowSums(Q1.hits.r)/rowSums(Q1.hits),digits=3)
#  CAR   COR   NEG   MCP BOOST LASSO   RND
#0.439 0.289 0.370 0.261 0.295 0.271 0.767 




########################################################################
# Q2

# Retrieve minor allele frequency (MAF) of the TP - SNPs


idQ2 = which(id.TPQ2==TRUE)			#which SNPs are TP (in 1:8020)


snpInfo[unlist(x.map[idQ2] [1]),]               #remap snpInfo of the first TP
#C1S1329           1  17826456    ARHGEF10L    Synonymous       C 0.000717
#C1S2255           1  37040084        GRIK3    Synonymous       T 0.000717
#...


MAF.Q2 <- numeric(length=71)
for(i in 1:71){
  MAF.Q2[i] <- snpInfo[unlist(x.map[idQ2[i]]),6] [1]   
}


# Split TP SNPs in common variants (MAF>0.01) and rare variants (MAF<0.01)

Q2.hits.c <- Q2.hits[,MAF.Q2>0.01]
dim(Q2.hits.c)
#7 6
Q2.hits.r <- Q2.hits[,MAF.Q2<0.01]
dim(Q2.hits.r)
#7 65


# Statistics of the TP selected by the 6 approaches under investigation

# Common variants
round(rowSums(Q2.hits.c)/rowSums(Q2.hits),digits=3)
#  CAR   COR   NEG   MCP BOOST LASSO   RND
#0.283 0.406 0.364 0.439 0.417 0.425 0.064 

# Rare variants
round(rowSums(Q2.hits.r)/rowSums(Q2.hits),digits=3)
#  CAR   COR   NEG   MCP BOOST LASSO   RND
#0.717 0.594 0.636 0.561 0.583 0.575 0.936 



