#
# 14 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#



# model sizes for the investigated SNP selection strategies

# for CAR and COR 

# read functions
library("fdrtool")


getThresh = function(score.mat)
{
  LFDR08 = numeric(200)

  for (i in 1:200)
  {
    cat("round", i, "\n")
    z = score.mat[i,]
    fdr.out = fdrtool(z, statistic="correlation", plot=FALSE, verbose=FALSE)

    LFDR08[i] = sum(fdr.out$lfdr < 0.8)
   }
   return( list(LFDR08=LFDR08) )
}




###########################
# Q1

# Read data
load(file="rda/COR.Q1.rda")
load(file="rda/CAR.Q1.rda")


# CAR score
th = getThresh(CAR.Q1)

# local FDR < 0.8
range( th$LFDR08 )    # 13 1153
median( th$LFDR08 )   # 217.5
IQR( th$LFDR08 )      # 198.75


# marginal correlation
th = getThresh(COR.Q1)

# local FDR < 0.8
range( th$LFDR08 )    # 65 1402
median( th$LFDR08 )   # 319
IQR( th$LFDR08 )      # 208.5


###########################
# Q2

# Read data
load(file="rda/COR.Q2.rda")
load(file="rda/CAR.Q2.rda")

# CAR score
th = getThresh(CAR.Q2)

# local FDR < 0.8
range( th$LFDR08 )    # 2 977
median( th$LFDR08 )   # 134.5
IQR( th$LFDR08 )      # 172.5


# marginal correlation
th = getThresh(COR.Q2)

# local FDR < 0.8
range( th$LFDR08 )    # 0 985
median( th$LFDR08 )   # 18.5
IQR( th$LFDR08 )      # 68.75


