#
# 14 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#

# if we make cutoff at some threshold, which true SNP has been picked how often?


# Read data
load(file="rda/workingdata.rda")

####
# number the true SNPs

sum(id.TPQ1) # 38
number.TPQ1 = numeric(8020)
number.TPQ1[which(id.TPQ1)] = 1:38

sum(id.TPQ2) # 71
number.TPQ2 = numeric(8020)
number.TPQ2[which(id.TPQ2)] = 1:71

####


getHits = function(stat, ntp, thresh)
{
  if (length(ntp) != length(stat)) stop("arguments must have same length")
  
  # randomize order (to avoid using input order for vanishing coefficients) 
  shuffle = sample(length(ntp)) 
  stat = stat[shuffle]
  ntp = ntp[shuffle]

  # sort statistics in decreasing magnitude
  ostat = order(abs(stat), decreasing=TRUE)

  hits = ntp[ostat[1:thresh]]
  hits = hits[hits > 0]

  return(hits)
}

# example
#getHits(COR.Q1[1,], number.TPQ1, 100)
#getHits(COR.Q1[1,], number.TPQ1, 50)


collectHits = function(stat.mat, ntp, thresh)
{
  B = dim(stat.mat)[1]

  counts = numeric(max(ntp))

  for (i in 1:B)
  {
     h = getHits(stat.mat[i,], ntp, thresh)
     counts[ h ] = counts[h] +1
  }

  return(counts)
}

##############
# results


thresh = 100


#### Q1

load(file="rda/CAR.Q1.rda")
load(file="rda/COR.Q1.rda")
load(file="rda/NEG.Q1.rda")
load(file="rda/MCP.Q1.rda")
load(file="rda/BOOST.Q1.rda")
load(file="rda/LASSO.Q1.rda")
load(file="rda/RND.Q1.rda")

Q1.hits = matrix(ncol=38, nrow=7)
rownames(Q1.hits) = c("CAR", "COR", "NEG", "MCP", "BOOST", "LASSO", "RND")
colnames(Q1.hits)=paste("S",1:38, sep="")

Q1.hits[1,] = collectHits(CAR.Q1, number.TPQ1, thresh)
Q1.hits[2,] = collectHits(COR.Q1, number.TPQ1, thresh)
Q1.hits[3,] = collectHits(NEG.Q1, number.TPQ1, thresh)
Q1.hits[4,] = collectHits(MCP.Q1, number.TPQ1, thresh)
Q1.hits[5,] = collectHits(BOOST.Q1, number.TPQ1, thresh)
Q1.hits[6,] = collectHits(LASSO.Q1, number.TPQ1, thresh)
Q1.hits[7,] = collectHits(RND.Q1, number.TPQ1, thresh)

save(Q1.hits, file="rda/Q1.hits.rda")


#### Q2

load(file="rda/CAR.Q2.rda")
load(file="rda/COR.Q2.rda")
load(file="rda/NEG.Q2.rda")
load(file="rda/MCP.Q2.rda")
load(file="rda/BOOST.Q2.rda")
load(file="rda/LASSO.Q2.rda")
load(file="rda/RND.Q2.rda")

Q2.hits = matrix(ncol=71, nrow=7)
rownames(Q2.hits) = c("CAR", "COR", "NEG", "MCP", "BOOST", "LASSO", "RND")
colnames(Q2.hits)=paste("S",1:71, sep="")

Q2.hits[1,] = collectHits(CAR.Q2, number.TPQ2, thresh)
Q2.hits[2,] = collectHits(COR.Q2, number.TPQ2, thresh)
Q2.hits[3,] = collectHits(NEG.Q2, number.TPQ2, thresh)
Q2.hits[4,] = collectHits(MCP.Q2, number.TPQ2, thresh)
Q2.hits[5,] = collectHits(BOOST.Q2, number.TPQ2, thresh)
Q2.hits[6,] = collectHits(LASSO.Q2, number.TPQ2, thresh)
Q2.hits[7,] = collectHits(RND.Q2, number.TPQ2, thresh)

save(Q2.hits, file="rda/Q2.hits.rda")

##############################


load("rda/Q1.hits.rda")
load("rda/Q2.hits.rda")


rowSums(Q1.hits)
#  CAR   COR   NEG   MCP BOOST LASSO   RND 
# 1483  1346  1195   911  1209  1143   101

Q1.hits
#        S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12 S13 S14 S15 S16 S17 S18 S19 S20
# CAR   145  1  9  1  5  5 33 14  5  14  91  12  11  10   6   0   2   1   0   2
# COR   161  0  0  0  0  0  0  2  0   0  25   0   0   0   0   1   0   0   0   0
# NEG    73  2 15  2  8 12 11  5  5  17  33  16  22  14  17   2  13   3   3   6
# MCP    58  3  3  4  1  1  3  6  1   2  16   1   1  10   6   2   1   2   1   2
# BOOST  82  0  1  1  3  2  5  4  3   4  31   3   2   8   3   1   8   4   2   3
# LASSO  73  0  3  1  1  3  3  4  0   7  24   1   2   5   1   3   5   3   0   2
# RND     3  2  6  1  4  3  2  2  1   2   4   3   4   4   4   2   5   0   0   2
#       S21 S22 S23 S24 S25 S26 S27 S28 S29 S30 S31 S32 S33 S34 S35 S36 S37 S38
# CAR     3   2   7   0   1  69   3  20   0  15 164  88  38 110  95 200 200 101
# COR     0   0   5   0   0   5   1   0   0   2 187  96  71 143 119 200 200 128
# NEG     0   5   1   4   4  64   4  18   3   7  50  87  15 136  77 194 200  47
# MCP     4   1   4   3   6  33   3  10   3   5  51  60   6 121  60 163 200  54
# BOOST   2   0   1   5   2  59   4  14   3   7  91  99  17 159  99 196 200  81
# LASSO   2   3   2   0   3  40   4  13   1   5  95  91  21 157  92 195 200  78
# RND     4   5   3   5   0   2   0   3   2   3   5   3   3   3   1   2   1   2


rowSums(Q2.hits)
#  CAR   COR   NEG   MCP BOOST LASSO   RND 
# 1159  1021   857   682   874   569   18

Q2.hits
#       S1 S2 S3 S4 S5 S6 S7 S8 S9 S10 S11 S12 S13 S14 S15 S16 S17 S18 S19 S20
# CAR    8 12 27 13 16 54 59 22  1   4   0   5  32   1   5  24   7   0   0   0
# COR    1  2  4  4  1 13 51  2  1   3   0   1  11   0   4  11  10   0   2   1
# NEG    4  5 12 11  2 32 16  8  0   2   0   7  16   3   4  13   4   2   2   1
# MCP    1  2  2  4  1  8 12  6  1   1   3   2   6   1   2   9   4   2   2   1
# BOOST  0  4  3  5  4 18 23  5  1   2   2   2  10   1   2  12   3   1   4   3
# LASSO  2  3  4  4  2  7 16  3  3   5   3   2   9   2   2   4   3   2   2   3
# RND    3  2  3  2  2  3  4  3  4   2   4   5   0   1   4   4   5   3   3   0
#       S21 S22 S23 S24 S25 S26 S27 S28 S29 S30 S31 S32 S33 S34 S35 S36 S37 S38
# CAR     0   5   1   1  17   9   0   0   9   4  23   2   0   2   0   5  11  15
# COR     4   3   1   2  14  10   0   1   1   4   4   3   0   0   0   4   2   3
# NEG     0   3   3   2  11   6   1   2   3   0  13   0   2   3   3   3   9   7
# MCP     2   4   4   2   9   7   2   2   4   5   7   0   1   3   1   4   4   4
# BOOST   1   1   5   2   8   6   2   0   1   2   5   0   0   2   1   4   3   6
# LASSO   2   1   1   2   9   3   0   2   4   3   2   1   3   2   5   2   4   5
# RND     1   3   2   4   4   0   4   5   0   3   2   1   5   2   3   2   1   0
#       S39 S40 S41 S42 S43 S44 S45 S46 S47 S48 S49 S50 S51 S52 S53 S54 S55 S56
# CAR     2   0   2   1   9  13   6  41  40   1   4  20   4   8  72  54   4  30
# COR     8   0   1   1   1   3  12  10  19   2  12   9   1  31  86  35  13  26
# NEG     2   3   3   3   4  13   5  25  28   3   6   9  12   4  53  27   3  19
# MCP     0   0   1   0   1   5   5   7  21   4   5   6   2   8  56  19   3  12
# BOOST   8   3   4   5   2   8   6  12  23   4   7   8   1   8  72  27   7  21
# LASSO   2   4   1   5   2   4   0   4  11   2   7   4   2   3  38  16   5   8
# RND     3   4   2   4   4   4   2   0   2   0   2   1   2   0   3   3   4   4
#       S57 S58 S59 S60 S61 S62 S63 S64 S65 S66 S67 S68 S69 S70 S71
# CAR     1   3  49   5  10   3   9   3   4  43  57  69   1  59 138
# COR     8   3  16   4  26   2  20  16  33  63  79  77   0  66 160
# NEG     1   3  32   6  16   7  17   9   8  30  54  60   1  49 127
# MCP     5   3  13   3  16   1   8   7  11  31  60  57   0  45 132
# BOOST   4   1  24   5  18   3  17  14  15  45  74  78   1  59 136
# LASSO   3   3   8   2  12   1  12   5  10  26  44  46   2  34 111
# RND     2   2   3   2   1   1   7   3   3   4   3   1   2   2   6


