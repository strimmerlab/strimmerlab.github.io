#
# 14 March 2012
#

The R scripts in this folder accompany

V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
"An efficient approach to simultaneous SNP selection: 
A case study on GAW17 data"
http://arxiv.org/abs/1203.3082


By running the R scripts in the given order 
(1-import.R, 2-preprocessing.R etc)
you should be able to completely replicate our study.

The GAW17 data can be obtained from the GAW17 consortium,
see  http://www.gaworkshop.org/gaw17/data.html for details.
The content of the distributed CD need to be copied into the folder 
GAW17-CD-ROM.


