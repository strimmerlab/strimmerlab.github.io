#
# 14 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#



# Import of GAW17 Unrelated Data

PATHCD="GAW17-CDROM"

# 1. Read SNP Data
########################################################################

tmp = read.csv(paste(PATHCD, "snp_info",sep="/"))
snpInfo = tmp[,-1]  
rownames(snpInfo) = tmp[,1] # use sample ids as row names

dim(snpInfo) #  24487     6
snpInfo[1:2,]
#       chromosome position         gene      snp_type variant      maf
#C1S672          1   845962 LOC100128838 Nonsynonymous       G 0.003587
#C1S688          1  1105324       TTLL10 Nonsynonymous       T 0.014347


########################################################################

#
# read snp data for chromosome 1-22
#

for (k in 1:22)
{
  cat("read data from chromosome", k, "\n")
  name = paste("c", k, "_snps.unr", sep="")
  tmp = read.csv(paste(PATHCD, name, sep="/"))
  if(k ==1)
    x = tmp[,-1]  
  else
    x = cbind(x, tmp[,-1])
}
rownames(x) = tmp[,1] # use sample ids as row names

dim(x) #  697 24487


x[1:3, 1:3]
#        C1S672 C1S688 C1S689
#NA19466    T/T    T/C    T/T
#NA19204    T/T    C/C    T/T
#NA19002    T/T    C/C    T/T


########################################################################

#
# import phenotypes
#

pheno = list()
for (k in 1:200)
{
  cat("read data from phenotype", k, "\n")
  name = paste("unr_phen.", k, sep="")
  tmp = read.csv(paste(PATHCD, name, sep="/"))
  pheno[[k]] = tmp
}

length(pheno) # 200
dim(pheno[[153]]) # 697 8


########################################################################

# true positive (from GAW17 answers PDF)

trueQ1 = read.table("truth/trueQ1.csv", header=TRUE)
trueQ2 = read.table("truth/trueQ2.csv", header=TRUE)
trueLtD = read.table("truth/trueLtD.csv", header=TRUE)


########################################################################

save(snpInfo, x, pheno, trueQ1, trueQ2, trueLtD, file="rda/gaw17unrelated.rda")




