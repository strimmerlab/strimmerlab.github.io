#
# 14 March 2012
#
# This file is part of the R code accompanying 
# V.Zuber, A.P. Duarte Silva, and K. Strimmer (2012)
# "An efficient approach to simultaneous SNP selection: 
#  A case study on GAW17 data"
# http://arxiv.org/abs/1203.3082
#


# compute regression coefficients / correlations /car scores
# for each snp for each repetition both for Q1 and Q2


# Read data
load(file="rda/workingdata.rda")


########################################################################
# CAR scores (shrinkage parameter lambda = 0.1)
#
# choice of lambda not critical, values 0.1, 0.3, 0.7 all give very 
# similar results

library("care")

# Q1
CAR.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("CAR.Q1, repetition", i, "\n")
  CAR.Q1[i,] = carscore(x, y1[,i], lambda=0.1, diagonal=FALSE ,verbose=FALSE)
}
save(CAR.Q1, file="rda/CAR.Q1.rda")

# Q2
CAR.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("CAR.Q2, repetition", i, "\n")
  CAR.Q2[i,] = carscore(x, y2[,i], lambda=0.1, diagonal=FALSE ,verbose=FALSE)
}
save(CAR.Q2, file="rda/CAR.Q2.rda")


########################################################################
# marginal correlations

library("care")

# Q1
COR.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("COR.Q1, repetition", i, "\n")
  COR.Q1[i,] = carscore(x, y1[,i], lambda=0, diagonal=TRUE ,verbose=FALSE)
}
save(COR.Q1, file="rda/COR.Q1.rda")

# Q2
COR.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("COR.Q2, repetition", i, "\n")
  COR.Q2[i,] = carscore(x, y2[,i], lambda=0, diagonal=TRUE ,verbose=FALSE)
}
save(COR.Q2, file="rda/COR.Q2.rda")


########################################################################
# HyperLasso - regression with NEG prior

# parameter lambda=85 selected to optimize ranking

neg.coeff = function(x, y, lambda=85)
{
  write.table(y, file="y.dat", row.names=FALSE, quote = FALSE, col.names=FALSE)
  write.table(x, file="x.dat", row.names=FALSE, quote = FALSE)

  runHLasso = paste("runHLasso -target y.dat -covariates x.dat  -o out.NEG.R -model_d 0 -lambda_d ", lambda, " -shape_d 0.1 -linear", sep="")

  system(runHLasso)
  out.NEG = dget("out.NEG.R")[[1]]
  file.remove(c("x.dat", "y.dat", "out.NEG.R"))

  idx = c(-1, -ncol(out.NEG))
  id.NEG = as.numeric(out.NEG[1, idx])+1
  beta.NEG = as.numeric(out.NEG[3, idx])

  score = numeric(ncol(x))  
  score[id.NEG] = beta.NEG 

  return(score) # return betas
}

# Q1
NEG.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("NEG.Q1, repetition", i, "\n")
  NEG.Q1[i,] = neg.coeff(x, y1[,i])
}
save(NEG.Q1, file="rda/NEG.Q1.rda")

# Q2
NEG.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("NEG.Q2, repetition", i, "\n")
  NEG.Q2[i,] = neg.coeff(x, y2[,i])
}
save(NEG.Q2, file="rda/NEG.Q2.rda")


########################################################################
# regression with MCP penalty 

# fixed shrinkage parameter lambda=0.1 was used
# (this value was chosen using crossvalidation)

library("ncvreg")

mcp.coeff = function(x, y, lambda)
{
  #lambda.seq=seq(0.05, 1, by=0.05)
  #cv.out=cv.ncvreg(X=x, y=y, family="gaussian", lambda=lambda.seq)  
  #cv.out=cv.ncvreg(X=x, y=y, family="gaussian", nlambda=10)

  #ncv = ncvreg(X=x, y=y, family="gaussian", penalty="MCP", lambda=cv.out$lambda)  
  #score = as.vector( ncv$beta[-1,cv.out$min] )

  ncv = ncvreg(X=x, y=y, family="gaussian", penalty="MCP", lambda=c(lambda, lambda))
  score = as.vector( ncv$beta[-1,1] )

  return( score )
}


# Q1
MCP.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("MCP.Q1, repetition", i, "\n")
  MCP.Q1[i,] = mcp.coeff(x, y1[,i], lambda=0.1)
}
save(MCP.Q1, file="rda/MCP.Q1.rda")

# Q2
MCP.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("MCP.Q2, repetition", i, "\n")
  MCP.Q2[i,] = mcp.coeff(x, y2[,i], lambda=0.1)
}
save(MCP.Q2, file="rda/MCP.Q2.rda")


########################################################################
# boosting (using default parameter nu = 0.1)

library("mboost")
boost.coeff = function(x, y, nu=0.1)
{
  boost.out = glmboost(y~x, control = boost_control(nu = nu)) 
  coeff = coefficients(boost.out, which = 2:(ncol(x)+1))
  return(coeff)
}

# Q1
BOOST.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("BOOST.Q1, repetition", i, "\n")
  BOOST.Q1[i,] = boost.coeff(x, y1[,i])
}
save(BOOST.Q1, file="rda/BOOST.Q1.rda")

# Q2
BOOST.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("BOOST.Q2, repetition", i, "\n")
  BOOST.Q2[i,] = boost.coeff(x, y2[,i])
}
save(BOOST.Q2, file="rda/BOOST.Q2.rda")


########################################################################
# lasso

library("glmnet")
lasso.coeff = function(x, y)
{
  lambda.run = cv.glmnet(x=x, y=y)$lambda.min
  glm.lasso = glmnet(x=x, y=y, family="gaussian", lambda=lambda.run, alpha=1)
  score = glm.lasso$beta

  return(as.vector(score))
}

# Q1
LASSO.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("LASSO.Q1, repetition", i, "\n")
  LASSO.Q1[i,] = lasso.coeff(x, y1[,i])
}
save(LASSO.Q1, file="rda/LASSO.Q1.rda")

# Q2
LASSO.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("LASSO.Q2, repetition", i, "\n")
  LASSO.Q2[i,] = lasso.coeff(x, y2[,i])
}
save(LASSO.Q2, file="rda/LASSO.Q2.rda")


########################################################################
# random order (as baseline reference)

# Q1
RND.Q1 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("RND.Q1, repetition", i, "\n")
  RND.Q1[i,] = sample(8020)/8020
}
save(RND.Q1, file="rda/RND.Q1.rda")

# Q2
RND.Q2 = matrix(0, nrow=200, ncol=8020)
for (i in 1:200)
{
  cat("RND.Q2, repetition", i, "\n")
  RND.Q2[i,] = sample(8020)/8020
}
save(RND.Q2, file="rda/RND.Q2.rda")




